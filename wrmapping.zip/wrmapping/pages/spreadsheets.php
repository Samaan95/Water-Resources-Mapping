
<?php 
session_start();

?>
<!DOC<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>SWMS</title>
  <link rel="icon" href="../images/logo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
 <style>
 div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}


div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}


div.tab button:hover {
    background-color: #ddd;
}


div.tab button.active {
    background-color: #b8deff;
}


.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
	 -webkit-animation: fadeEffect 1s;
    animation: fadeEffect 1s; /* Fading effect takes 1 second */

}
@-webkit-keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}

@keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}
  </style> 

 <link rel="stylesheet" href="../css/general_css.css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50" >

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid" style=" box-shadow: 0px 5px 5px #888888;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
        <a  href="home_page.php"><img src= "../images/logo.jpg"   width="60" height="60" style="position: fixed;" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
     <ul class="nav navbar-nav navbar-right" style="min-height:30px !important">
        <li><a href="home_page.php">HOME</a></li>
       
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">WATER SYSTEM
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="public_map.php">Water Mapping</a></li>
           <li><a href="converter.php">Quality Indicators</a></li>
			<li><a href="spreadsheets.php">Dashboard</a></li>
			<li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php">Settings</a>';}?> </li>
			<?php 
		 if(isset($_SESSION["first_name"])){
			 echo '<li><a style="background-color:#e007076e" href="../php/logout.php">Logout</a></li>';}
	
		 ?>
          </ul>
        </li>
		<li><a href="investigator.php">INVESTIGTORS</a></li>
		<li><a href="publication.php">PUBLICTOINS</a></li>
		
          <li><a href="#contact">CONTACT</a></li>
		
        <li><a style="padding-top: 13px;padding-bottom: 13px;" href="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo '#';}?> " class="btn btn-info btn-lg" data-toggle="modal" data-target="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo "#myModal";}?>"><span class="glyphicon glyphicon-log-in"></span> 
		<?php 
		 if(isset($_SESSION["first_name"])){
			 echo $_SESSION["first_name"] ;}
		 else{ 
		 echo "Login";}
		 ?></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
	
	 <h3 class="text-center" style=" margin-top:10%">Water Dashboard</h3>
	<div class="row" style="margin-left: 14%; margin-right: 10%; margin-top:1%; width : 70%" >
  <div class="col-sm-4">
  <div class="form-group">
  <label for="sel1">Select City:</label>
  <select class="form-control" id="sel1">
    <option value="0"></option>
   
  </select>
</div>
  </div>
  <div class="col-sm-4">
  <div class="form-group">
  <label for="sel2">Select Region:</label>
  <select class="form-control" id="sel2">
    <option  value="0"></option>
   
  </select>
</div>
  </div>
   <div class="col-sm-4">
  <div class="form-group">
  <label for="sel3">Select Resource:</label>
  <select class="form-control" id="sel3">
    <option  value="0"></option>
  
  </select>
</div>
  </div>
</div>


	<!-- tabs -->
	<ul class="nav nav-tabs" style="margin-left: 15%; margin-right: 10%; margin-top:1%; width : 70%">
  <li class="active"><a data-toggle="tab" href="#quantity">Quantity</a></li>
  <li><a data-toggle="tab" href="#quality">Quality</a></li>
  <a href="#" class="btn btn-default" onclick='printDiv();'>
    <span class="glyphicon glyphicon-print"></span> Print 
  </a>
 <a href="#" id="cmd" class="btn btn-default" >
    <span class="glyphicon glyphicon-download"></span> generate PDF 
  </a>
   
   <div id="editor"></div>
</ul>

<div class="tab-content"  style="margin-left: 15%; width : 70%; color: black !important;box-shadow: 0px 5px 5px #888888;" id="content">
  <div id="quantity" class="tab-pane fade in active" style=" border-radius: 10px; padding-left:3%; padding-top:2%; padding-bottom:2%;">
  <!-- info -->
  <img src= "../images/logo.jpg"   width="60" height="60"/>
   <div class="row">
  <div class="col-sm-5" >
  <h5 style="color:black; padding-left:4%;"><u><strong>Water Resource Info</u></strong></h5>
    <div class="row">
  <div class="col-sm-6" id="city">City:</div>
  <div class="col-sm-6" id="region">Region:</div>
  <div class="col-sm-6" id ="coord">Coordination:</div>
   <div class="col-sm-6" id ="wr">Resource Name:</div>
   
</div>
  </div>
 <div  class="col-sm-5"  >
  <h5 style="color:black; padding-left:4%;"><strong><u>Related Farms</u></strong></h5>
 <div class="row">
  <div class="col-sm-8" id="relatedFarms"></div>
   
</div>
		
  </div>
   
</div>
<hr>

<h3 >Water Consumption Mapping</h3>
<h5 style="font-size: 15px;text-decoration: underline">General Consumption</h5>
 <div class="row">
  <div class="col-sm-6">
    <div id="chart_div_dev_month" ></div>
  </div>
 <div  class="col-sm-5">
  <div id="piechartMonth" ></div>
  </div>
</div>
	
	<div class="row">
  <div class="col-sm-6">
   <div id="chart_div_dev_year" ></div>
  </div>
 <div  class="col-sm-5">
  <div id="piechartYear" ></div>
  </div>
</div>
	
	<div class="row">
  <div class="col-sm-6">
   <div id="chart_div_dev_season" ></div>
  </div>
 <div  class="col-sm-5">
  <div id="piechartSeason" ></div>
  </div>
</div>

	
  </div>
  <div id="quality" class="tab-pane fade" style=" border-radius: 10px; padding-left:3%; padding-top:2%; padding-bottom:2%;">
    <!-- info -->
	<img src= "../images/logo.jpg"   width="60" height="60"/>
	<div class="row">
  <div class="col-sm-5" >
  <h5 style="color:black; padding-left:4%;"><u><strong>Water Resource Info</u></strong></h5>
    <div class="row">
  <div class="col-sm-6" id="city2">City:</div>
  <div class="col-sm-6" id="region2">Region:</div>
  <div class="col-sm-6" id ="coord2">Coordination:</div>
   <div class="col-sm-6" id ="wr2">Resource Name:</div>
   
</div>
  </div>
 <div  class="col-sm-5"  >
  <h5 style="color:black; padding-left:4%;"><strong><u>Related Farms</u></strong></h5>
 <div class="row">
  <div class="col-sm-8" id="relatedFarms2"></div>
   
</div>
		
  </div>
   
</div>
  
<hr>
<h3 >Water Quality Mapping</h3>
<div class="container"   style=" width:99%;" >
  
  <h2>Quality Indicators Status</h2>
             
  <table class="table table-striped" >
    <thead>
      <tr>
        <th>Status</th>
        <th>Parameters</th>
        <th>Hazard</th>
      </tr>
    </thead>
    <tbody>
      <tr id="ecw_content">
       
      </tr>
   <tr id="sar_content">
       
      </tr>
	 
	  <tr id="cl_content">
       
      </tr>
	  <tr id="b_content">
       
      </tr>
	  <tr id="ph_content">
       
      </tr>
	  <tr id="rsc_content">
       
      </tr>
	  <tr id="no3_content">
       
      </tr>
    </tbody>
  </table>
  <div class="row">
  <div id="qual1" class="col-sm-6">
  
  </div>
 <div  id="qual2"class="col-sm-5">
  
  </div>
</div>
</div>

</div>
</div>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
	 google.charts.setOnLoadCallback(drawQuality);
	 google.charts.setOnLoadCallback(drawDevYear);
	  google.charts.setOnLoadCallback(drawDevMonth);
	   google.charts.setOnLoadCallback(drawDevSeason);
	   
    </script>
	  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
     
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Sign In</h4>
        </div>
        <div class="modal-body">
		  
		 <div style="background-color:red; color:white" id="login_msg"> <?php 
		   if(!isset($_SESSION["user_name"])){
			 echo $_SESSION['login_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
          <form id="login_form" method="post">
		 
            <div class="form-group">
              <label for="usrname"  ><span class="glyphicon glyphicon-user"></span> User Name </label>
              <input required="true" name="username" type="text" class="form-control" id="username" placeholder="Enter Username">
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-asterisk"></span> Password </label>
              <input required="true" name="password" type="password" class="form-control" id="password" placeholder="Enter Password">
            </div>
           
              <button type="button" class="btn btn-block" id="login_btn" name="login_btn">Sign In 
                <span class="glyphicon glyphicon-ok"></span>
              </button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal">
            <span class="glyphicon glyphicon-remove"></span> Cancel
          </button>
          <p>Need <a href="#">Sign Up?</a></p>
        </div>
      </div>
    </div>
  </div>
<!-- Container (Contact Section) -->
<div id="contact" class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center"><em>We love our fans!</em></p>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Ramallah, Palestine</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +970 597026183</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
	 
	<form role="form" action="../php/contact_messages.php"  method="post">
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea required="true" class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <br>
	  
      <div class="row">
        <div class="col-md-12 form-group">
          <button id="contact_btn" name="contant_btn" class="btn pull-right" type="button">Send</button>
        </div>
		
      </div>
	   <div style="background-color:red; color:white" id="contact_msg"> <?php 
		    if(isset($_SESSION['contact_error'])){
			 echo $_SESSION['contact_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
	 
    </div>
	</form>
  </div>
 
</div>





<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>WRMapping Project Made By <a href="https://www.alquds.edu" data-toggle="tooltip" title="Visit Alquds Univesity">www.alquds.edu</a></p> 
</footer>

<script src="../js/bootstrap_scripts.js"></script>
<script src="../js/contact.js"></script>
<script src="../js/login.js"></script>
<script src="../js/spreadsheet.js"></script>

 <script src="https://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
 <script src="https://docraptor.com/docraptor-1.0.0.js"></script>
<script>


$('#cmd').click(function() {
      DocRaptor.createAndDownloadDoc("YOUR_API_KEY_HERE", {
        test: true, // test documents are free, but watermarked
        type: "pdf",
        document_content: document.querySelector('#content').innerHTML, // use this page's HTML
        // document_content: "<h1>Hello world!</h1>",               // or supply HTML directly
        // document_url: "http://example.com/your-page",            // or use a URL
        // javascript: true,                                        // enable JavaScript processing
        // prince_options: {
        //   media: "screen",                                       // use screen styles instead of print styles
        // }
      })
    });
</script>
<!-- <script src="../js/logout_timer.js"></script>  -->


</body>
</html>
<?php 
$_SESSION['contact_error']='';
?>
