
<?php 
session_start();
if(!isset($_SESSION["user_name"])){
header("Location: ../pages/home_page.php");}
?>
<!DOC<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>SWMS</title>
  <link rel="icon" href="../images/logo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <style>
 div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #ffffff;
}


div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}


div.tab button:hover {
    background-color: #ddd;
}


div.tab button.active {
    background-color: #b8deff;
}


.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
	 -webkit-animation: fadeEffect 1s;
    animation: fadeEffect 1s; /* Fading effect takes 1 second */

}
@-webkit-keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}

@keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}
  </style> 

 <link rel="stylesheet" href="../css/general_css.css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50" >

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid" style=" box-shadow: 0px 5px 5px #888888;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a  href="home_page.php"><img src= "../images/logo.jpg"   width="60" height="60" style="position: fixed;" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar" >
      <ul class="nav navbar-nav navbar-right" style="min-height:30px !important">
	  <li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php"><img src= "../images/setb.png" class="img-circle" alt="Cinque Terre" width="25" height="25"/></a>';}?> </li>
        <li><a href="home_page.php">HOME</a></li>
        
          
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" >WATER SYSTEM
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="public_map.php">Water Mapping</a></li>
            <li><a href="converter.php">Quality Indicators</a></li>
			<li><a href="spreadsheets.php">Dashboard</a></li>
			<li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php">Settings</a>';}?> </li>
			<?php 
		 if(isset($_SESSION["first_name"])){
			 echo '<li><a style="background-color:#e007076e" href="../php/logout.php">Logout</a></li>';}
	
		 ?>
          </ul>
        </li>
		<li><a href="investigator.php">INVESTIGTORS</a></li>
		<li><a href="publication.php">PUBLICTOINS</a></li>
		<li><a href="#contact">CONTACT</a></li>
        <li > <a style="padding-top: 13px;padding-bottom: 13px;" class="btn btn-info btn-lg"  href="#personal"> <img src="<?php if(isset($_SESSION["first_name"])){echo $_SESSION["user_pic"] ;}?>" class="img-circle" alt="Cinque Terre" width="25" height="25">
		<?php 
		 if(isset($_SESSION["first_name"])){
			 echo $_SESSION["first_name"] ;}
	
		 ?></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
	
	 <!-- map -->
<div id="googft-mapCanvas" style=" height: 85%; width: 100%;margin-top:3%; box-shadow: 0px 10px 5px #888888;"></div>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyCl-DZJeFdTqec7WZjmPfCTHs4xWW-6Ffw&amp;libraries=visualization"></script>
<script type="text/javascript" src="https://apis.google.com/js/client.js?onload=ftOnLoadClientApi"></script>
<script src="../js/map_scripts.js"></script>
<script src="../js/waterMarkers.js"></script>
<script src="../js/regionMarkers.js"></script>
<script src="../js/cityMarkers.js"></script>
<script src="../js/agriMarkers.js"></script>
<div  class="container">
<div id="legend" class="row" style=" box-shadow: 0px 5px 5px #888888; height:9%">
  
</div>
</div>
<div id="personal" class="container">
 <h3 class="text-center">Personal Information</h3>
<h3 class="text-center"> <img src="<?php if(isset($_SESSION["first_name"])){echo $_SESSION["user_pic"] ;}?>" class="img-circle" alt="Cinque Terre" width="20%" height="25%" ></h3>
<h3 class="text-center" style="font-size:17px"><?php if(isset($_SESSION["first_name"])){echo ($_SESSION["first_name"]. ' ' .$_SESSION["last_name"]) ;}?> </h3>
<div  class="text-center"><?php if(isset($_SESSION["first_name"])){echo ('Gender-Age: '.' '.$_SESSION["user_gender"]. ', ' .$_SESSION["user_age"]) ;}?> </div>
<div  class="text-center"><?php if(isset($_SESSION["first_name"])){echo ('Phone: '.' '.$_SESSION["user_phone"]) ;}?> </div>
<div  class="text-center"><?php if(isset($_SESSION["first_name"])){echo ('E-mail: '.' '.$_SESSION["email"]) ;}?> </div>
<div  class="text-center"><?php if(isset($_SESSION["first_name"])){echo ('Address: '.' '.$_SESSION["region_name"]. ', ' .$_SESSION["city_name"]) ;}?> </div>
<div  class="text-center"><?php if(isset($_SESSION["first_name"])){echo ('Type: '.' '.$_SESSION["type_name"]) ;}?> </div>
</div>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
	  
	 google.charts.setOnLoadCallback(drawQuality);
	 google.charts.setOnLoadCallback(drawPop);
	 google.charts.setOnLoadCallback(drawPopRegion);
	  google.charts.setOnLoadCallback(drawDevYear);
	   google.charts.setOnLoadCallback(drawDevMonth);
	   google.charts.setOnLoadCallback(drawLandConsumption);
	   
	  
    </script>
	
<!-- Container (Contact Section) -->
<div id="contact" class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center"><em>We love our fans!</em></p>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Ramallah, Palestine</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +970 597026183</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
	 
	<form role="form" action="../php/contact_messages.php"  method="post">
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea required="true" class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <br>
	  
      <div class="row">
        <div class="col-md-12 form-group">
          <button id="contact_btn" name="contant_btn" class="btn pull-right" type="button">Send</button>
        </div>
		
      </div>
	   <div style="background-color:red; color:white" id="contact_msg"> <?php 
		    if(isset($_SESSION['contact_error'])){
			 echo $_SESSION['contact_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
	 
    </div>
	</form>
  </div>
 
</div>

<!-- Add Google Maps -->



<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>WRMapping Project Made By <a href="https://www.alquds.edu" data-toggle="tooltip" title="Visit Alquds Univesity">www.alquds.edu</a></p> 
</footer>

<script src="../js/bootstrap_scripts.js"></script>
<script src="../js/contact.js"></script>

<!-- <script src="../js/logout_timer.js"></script>  -->


</body>
</html>
<?php 
$_SESSION['contact_error']='';
?>
