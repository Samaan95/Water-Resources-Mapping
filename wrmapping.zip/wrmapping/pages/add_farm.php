
<?php 
session_start();

?>
<!DOC<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>SWMS</title>
  <link rel="icon" href="../images/logo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
 <style>
 div.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}


div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}


div.tab button:hover {
    background-color: #ddd;
}


div.tab button.active {
    background-color: #b8deff;
}


.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
	 -webkit-animation: fadeEffect 1s;
    animation: fadeEffect 1s; /* Fading effect takes 1 second */

}
@-webkit-keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}

@keyframes fadeEffect {
    from {opacity: 0;}
    to {opacity: 1;}
}
  </style> 

 <link rel="stylesheet" href="../css/general_css.css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50" >

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid" style=" box-shadow: 0px 5px 5px #888888;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a  href="home_page.php"><img src= "../images/logo.jpg"   width="60" height="60" style="position: fixed;" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right" style="min-height:30px !important">
        <li><a href="home_page.php">HOME</a></li>
       
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">WATER SYSTEM
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="public_map.php">Water Mapping</a></li>
           <li><a href="converter.php">Quality Indicators</a></li>
			<li><a href="spreadsheets.php">Dashboard</a></li>
			<li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php">Settings</a>';}?> </li>
			<?php 
		 if(isset($_SESSION["first_name"])){
			 echo '<li><a style="background-color:#e007076e" href="../php/logout.php">Logout</a></li>';}
	
		 ?>
          </ul>
        </li>
		<li><a href="investigator.php">INVESTIGTORS</a></li>
		<li><a href="publication.php">PUBLICTOINS</a></li>
		
          <li><a href="#contact">CONTACT</a></li>
		
        <li><a style="padding-top: 13px;padding-bottom: 13px;" href="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo '#';}?> " class="btn btn-info btn-lg" data-toggle="modal" data-target="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo "#myModal";}?>"><span class="glyphicon glyphicon-log-in"></span> 
		<?php 
		 if(isset($_SESSION["first_name"])){
			 echo $_SESSION["first_name"] ;}
		 else{ 
		 echo "Login";}
		 ?></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
	
	 <h3 class="text-center" style=" margin-top:10%">Add Farm</h3>
	<div  class="container" style=" box-shadow: 0px 5px 5px #888888;">
<nav class="navbar navbar-default"style="z-index:100" >
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="settings.php">Settings</a>
    </div>
	<div class="collapse navbar-collapse" id="myNavbar">
   <ul class="nav navbar-nav">
     
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Water Resource
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
		<li><a href="add_resource.php">+Add Resource</a></li>
          <li><a href="add_quality.php">+Add Quality Data</a></li>
          <li><a href="add_quantity.php">+Add Quantity Data</a></li>
		 
          
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Agricuture
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="add_farm.php">+Add Farm</a></li>
          <li><a href="plant.php">+plant</a></li>
		   <li><a href="add_consumption_agri.php">+Add Consumption Data</a></li>
        </ul>
      </li>
	   <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Population
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
           <li><a href="add_consumption_pop.php">+Add Consumption Data</a></li>
        </ul>
      </li>
    </ul>
	</div>
  </div>
</nav>
       <form role="form"  method="post">
  <div class="row" >
  <div class="col-sm-4">
  <div class="form-group">
  <label for="sel1">Select City:</label>
  <select name="city" class="form-control" id="sel1">
    <option value="0"></option>
   
  </select>
</div>
  </div>
  <div class="col-sm-4">
  <div class="form-group">
  <label for="sel2">Select Region:</label>
  <select name="region" class="form-control" id="sel2">
    <option  value="0"></option>
   
  </select>
</div>
  </div>
   <div class="col-sm-4">
  <div class="form-group">
  <label for="sel3">Farm Type:</label>
  <select name="type" class="form-control" id="sel3">
    <option  value="0"></option>
  
  </select>
</div>
  </div>
  <div class="col-sm-4">
   <div class="form-group">
<label for="farm_name">Farm Name</label>					    	
	<input name="farm_name" class="form-control" id="farm_name" type="text"    >									  	
	</div>	
	</div>	
	 <div class="col-sm-4">
   <div class="form-group">
<label for="area">Farm Area m2</label>					    	
	<input name="area" class="form-control" id="area" type="number" placeholder="m2" >								  	
	</div>	
	</div>	
  <div class="col-sm-4">
   <div class="form-group">
<label for="lat">Latitude</label>					    	
	<input class="form-control" name="lat" id="lat-input" type="number"  >									  	
	</div>	
	</div>	
 <div class="col-sm-4">	
  <div class="form-group">
	<label for="lng">Longitude</label>
	<input name="lng" class="form-control" id="lng-input" type="number"  >
		</div>
		</div>	
  
  </div>
   <div class="row">
        <div class="col-md-12 form-group" style="margin-top:5%">
          <button id="add_btn" name="add_btn" class="btn pull-right" type="button">+Add</button>
        </div>
      </div>
	  
  </form>
  <div style="background-color:red; color:white" id="add_msg"></div>
  <br>
  <label>Choose the coordinations:</label>
  <div id="googMap" style="padding-top:10px ;width: 100%; height: 400px;" ></div>	
	</div>
	  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
     
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Sign In</h4>
        </div>
        <div class="modal-body">
		  
		 <div style="background-color:red; color:white" id="login_msg"> <?php 
		   if(!isset($_SESSION["user_name"])){
			 echo $_SESSION['login_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
          <form id="login_form" method="post">
		 
            <div class="form-group">
              <label for="usrname"  ><span class="glyphicon glyphicon-user"></span> User Name </label>
              <input required="true" name="username" type="text" class="form-control" id="username" placeholder="Enter Username">
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-asterisk"></span> Password </label>
              <input required="true" name="password" type="password" class="form-control" id="password" placeholder="Enter Password">
            </div>
           
              <button type="button" class="btn btn-block" id="login_btn" name="login_btn">Sign In 
                <span class="glyphicon glyphicon-ok"></span>
              </button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal">
            <span class="glyphicon glyphicon-remove"></span> Cancel
          </button>
          <p>Need <a href="#">Sign Up?</a></p>
        </div>
      </div>
    </div>
  </div>
<!-- Container (Contact Section) -->
<div id="contact" class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center"><em>We love our fans!</em></p>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Ramallah, Palestine</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +970 597026183</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
	 
	<form role="form" action="../php/contact_messages.php"  method="post">
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea required="true" class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <br>
	  
      <div class="row">
        <div class="col-md-12 form-group">
          <button id="contact_btn" name="contant_btn" class="btn pull-right" type="button">Send</button>
        </div>
		
      </div>
	   <div style="background-color:red; color:white" id="contact_msg"> <?php 
		    if(isset($_SESSION['contact_error'])){
			 echo $_SESSION['contact_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
	 
    </div>
	</form>
  </div>
 
</div>





<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>WRMapping Project Made By <a href="https://www.alquds.edu" data-toggle="tooltip" title="Visit Alquds Univesity">www.alquds.edu</a></p> 
</footer>

<script src="../js/bootstrap_scripts.js"></script>
<script src="../js/contact.js"></script>
<script src="../js/login.js"></script>
<script src="../js/convert.js"></script>
<script src="../js/add_farm.js"></script>
<script>
function myMap() {
    var myCenter = new google.maps.LatLng(31.919191, 35.2158);
var mapProp = {center:myCenter, zoom:12, mapTypeId:google.maps.MapTypeId.ROADMAP};
var map = new google.maps.Map(document.getElementById("googMap"),mapProp);
var marker = new google.maps.Marker({position:myCenter});
marker.setMap(map);
google.maps.event.addListener(map, "click", function(event) {
    var lat = event.latLng.lat();
    var lng = event.latLng.lng();
    $('#lat-input').val(lat);
	  $('#lng-input').val(lng);
	  marker.setMap(null);
	   var pos = new google.maps.LatLng(lat, lng);
    marker = new google.maps.Marker({position:pos});
	marker.setMap(map);
});
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCl-DZJeFdTqec7WZjmPfCTHs4xWW-6Ffw&callback=myMap"></script>
<!-- <script src="../js/logout_timer.js"></script>  -->


</body>
</html>
<?php 
$_SESSION['contact_error']='';
?>
