
<?php 
session_start();

?>
<!DOC<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>SWMS</title>
  <link rel="icon" href="../images/logo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
 <style>
 *, *:after, *:before { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; }

body {
	background: white;
	font-family: 'Lato', Arial, sans-serif;
	color: #fff;
}

.wrapper {
	margin: 0 auto 100px auto;
	max-width: 960px;
}

.stage {
	list-style: none;
	
}

/*************************************
Build the scene and rotate on hover
**************************************/

.scene {
	width: 260px;
	height: 300px;
	margin: 30px;
	
	float: left;
	-webkit-perspective: 1000px;
	-moz-perspective: 1000px;
	perspective: 1000px;
}
.scene2 {
	width: 260px;
	height: 300px;
	margin: 30px;
	
	float: left;
	-webkit-perspective: 1000px;
	-moz-perspective: 1000px;
	perspective: 1000px;
}
.movie {
	width: 260px;
	height: 400px;
	-webkit-transform-style: preserve-3d;
	-moz-transform-style: preserve-3d;
	transform-style: preserve-3d;
	-webkit-transform: translateZ(-130px);
	-moz-transform: translateZ(-130px);
	transform: translateZ(-130px);
	-webkit-transition: -webkit-transform 350ms;
	-moz-transition: -moz-transform 350ms;
	transition: transform 350ms;
}

.movie:hover {
	-webkit-transform: rotateY(-78deg) translateZ(20px);
	-moz-transform: rotateY(-78deg) translateZ(20px);
	transform: rotateY(-78deg) translateZ(20px);
}

/*************************************
Transform and style the two planes
**************************************/

.movie .poster, 
.movie .info {
	position: absolute;
	width: 260px;
	height: 260px;
	background-color: #fff;
	-webkit-backface-visibility: hidden;
	-moz-backface-visibility: hidden;
	backface-visibility: hidden;
}

.movie .poster  {
	-webkit-transform: translateZ(130px);
	-moz-transform: translateZ(130px);
	transform: translateZ(130px);
	background-size: cover;
	background-repeat: no-repeat;
}

.movie .info {
	-webkit-transform: rotateY(90deg) translateZ(130px);
	-moz-transform: rotateY(90deg) translateZ(130px);
	transform: rotateY(90deg) translateZ(130px);
	border: 1px solid #B8B5B5;
	font-size: 0.75em;
}

/*************************************
Shadow beneath the 3D object
**************************************/

.csstransforms3d .movie::after {
	content: '';
	width: 260px;
	height: 260px;
	position: absolute;
	bottom: 0;
	box-shadow: 0 30px 50px rgba(0,0,0,0.3);
	-webkit-transform-origin: 100% 100%;
	-moz-transform-origin: 100% 100%;
	transform-origin: 100% 100%;
	-webkit-transform: rotateX(90deg) translateY(130px);
	-moz-transform: rotateX(90deg) translateY(130px);
	transform: rotateX(90deg) translateY(130px);
	-webkit-transition: box-shadow 350ms;
	-moz-transition: box-shadow 350ms;
	transition: box-shadow 350ms;
}

.csstransforms3d .movie:hover::after {
	box-shadow: 20px -5px 50px rgba(0,0,0,0.3);
}

/*************************************
Movie information
**************************************/


.info header h1 {
	margin: 0 0 2px;
	font-size: 1.4em;
}

.info header .rating {
	border: 1px solid #FFF;
	padding: 0px 3px;
}

.info p {
	padding: 1.2em 1.4em;
	margin: 2px 0 0;
	font-weight: 700;
	color: #666;
	line-height: 1.4em;
	border-top: 10px solid #555;
}

/*************************************
Generate "lighting" using box shadows
**************************************/

.movie .poster,
.movie .info,
.movie .info header {
	-webkit-transition: box-shadow 350ms;
	-moz-transition: box-shadow 350ms;
	transition: box-shadow 350ms;
}

.csstransforms3d .movie .poster {
	box-shadow: inset 0px 0px 40px rgba(255,255,255,0);
}

.csstransforms3d .movie:hover .poster {
	box-shadow: inset 300px 0px 40px rgba(255,255,255,0.8);
}

.csstransforms3d .movie .info, 
.csstransforms3d .movie .info header {
	box-shadow: inset -300px 0px 40px rgba(0,0,0,0.5);
}

.csstransforms3d .movie:hover .info, 
.csstransforms3d .movie:hover .info header {
	box-shadow: inset 0px 0px 40px rgba(0,0,0,0);
}

/*************************************
Posters and still images
**************************************/



.scene:nth-child(1) .poster {
  background-image: url(../images/user/rad.jpg);
}
.scene:nth-child(2) .poster {
  background-image: url(../images/user/amer.jpg);
}
.scene2:nth-child(1) .movie .poster {
  background-image: url(../images/user/moh2.jpg);
}

.scene2:nth-child(2) .poster {
  background-image: url(../images/user/zen.jpg);
}
.scene2:nth-child(3) .poster {
  background-image: url(../images/user/ala.jpg);
}
/*************************************
Fallback
**************************************/
.no-csstransforms3d .movie .poster, 
.no-csstransforms3d .movie .info {
	position: relative;
}

/*************************************
Media Queries
**************************************/
@media screen and (max-width: 60.75em){
	.scene {
		float: none;
		margin: 30px auto 30px;
	}
}
@import url(http://fonts.googleapis.com/css?family=Lato:300,400,900);
@font-face {
	font-family: 'codropsicons';
	src:url('../fonts/codropsicons/codropsicons.eot');
	src:url('../fonts/codropsicons/codropsicons.eot?#iefix') format('embedded-opentype'),
		url('../fonts/codropsicons/codropsicons.woff') format('woff'),
		url('../fonts/codropsicons/codropsicons.ttf') format('truetype'),
		url('../fonts/codropsicons/codropsicons.svg#codropsicons') format('svg');
	font-weight: normal;
	font-style: normal;
}

.clearfix:before,
.clearfix:after {
    content: " ";
    display: table;
}

.clearfix:after {
    clear: both;
}

.container > header,
.codrops-top {
	font-family: 'Lato', Arial, sans-serif;
}

.container > header {
	margin: 0 auto;
	padding: 2em;
	text-align: center;
	background: rgba(0,0,0,0.01);
}

.container > header h1 {
	font-size: 25px;
	line-height: 1.3;
	margin: 0;
	font-weight: 300;
}

.container > header span {
	display: block;
	font-size: 60%;
	opacity: 0.7;
	padding: 0 0 0.6em 0.1em;
}

/* To Navigation Style */
.codrops-top {
	background: #fff;
	background: rgba(255, 255, 255, 0.6);
	text-transform: uppercase;
	width: 100%;
	font-size: 0.69em;
	line-height: 2.2;
}

.codrops-top a {
	text-decoration: none;
	padding: 0 1em;
	letter-spacing: 0.1em;
	color: #888;
	display: inline-block;
}

.codrops-top a:hover {
	background: rgba(255,255,255,0.95);
	color: #333;
}

.codrops-top span.right {
	float: right;
}

.codrops-top span.right a {
	float: left;
	display: block;
}

.codrops-icon:before {
	font-family: 'codropsicons';
	margin: 0 4px;
	speak: none;
	font-style: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	line-height: 1;
	-webkit-font-smoothing: antialiased;
}

.codrops-icon-drop:before {
	content: "\e001";
}

.codrops-icon-prev:before {
	content: "\e004";
}

/* Demo Buttons Style */
.codrops-demos {
	padding-top: 1em;
	font-size: 0.9em;
}

.codrops-demos a {
	text-decoration: none;
	outline: none;
	display: inline-block;
	margin: 0.5em;
	padding: 0.7em 1.1em;
	border: 3px solid #b1aea6;
	color: #b1aea6;
	font-weight: 700;
}

.codrops-demos a:hover,
.codrops-demos a.current-demo,
.codrops-demos a.current-demo:hover {
	border-color: #89867e;
	color: #89867e;
}

@media screen and (max-width: 25em) {

	.codrops-icon span {
		display: none;
	}

}

  </style> 

 <link rel="stylesheet" href="../css/general_css.css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50" >

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid" style=" box-shadow: 0px 5px 5px #888888;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <a  href="home_page.php"><img src= "../images/logo.jpg"   width="60" height="60" style="position: fixed;" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
     <ul class="nav navbar-nav navbar-right" style="min-height:30px !important">
        <li><a href="home_page.php">HOME</a></li>
       
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">WATER SYSTEM
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="public_map.php">Water Mapping</a></li>
           <li><a href="converter.php">Quality Indicators</a></li>
			<li><a href="spreadsheets.php">Dashboard</a></li>
			<li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php">Settings</a>';}?> </li>
			<?php 
		 if(isset($_SESSION["first_name"])){
			 echo '<li><a style="background-color:#e007076e" href="../php/logout.php">Logout</a></li>';}
	
		 ?>
          </ul>
        </li>
		<li><a href="investigator.php">INVESTIGTORS</a></li>
		<li><a href="publication.php">PUBLICTOINS</a></li>
	
          <li><a href="#contact">CONTACT</a></li>
		
        <li><a style="padding-top: 13px;padding-bottom: 13px;" href="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo '#';}?> " class="btn btn-info btn-lg" data-toggle="modal" data-target="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo "#myModal";}?>"><span class="glyphicon glyphicon-log-in"></span> 
		<?php 
		 if(isset($_SESSION["first_name"])){
			 echo $_SESSION["first_name"] ;}
		 else{ 
		 echo "Login";}
		 ?></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
	
	<div class="container">
			<!-- Top Navigation -->
		
			<header>
				<h1>Investigators<span></span></h1>  
			</header>
			<div class="wrapper">
				<ul class="stage clearfix">

					<li class="scene" style="margin-right: 120px;">
						<div class="movie" onclick="return true">
							<div class="poster" style="box-shadow: 5px 0px 5px #0090f7;"></div>
							<div class="info"style="box-shadow: 5px 0px 5px #0090f7;">
								<header style="margin-left:10px">
									<h1>Radwan Qasrawi</h1>
									<span class="year">Instructor  at CS & IT department</span><br>
									<span >E: radwan@planet.edu</span><br>
									<span class="duration">T: +972-02-2799753</span>
								</header>
								<p>
								Works at Alquds university. the supervisor of the project.
								</p>
							</div>
						</div>
					</li>

					<li class="scene"style="margin-left: 120px;">
						<div class="movie" onclick="return true">
							<div class="poster" style="box-shadow: 5px 0px 5px #0090f7;"></div>
							<div class="info" style="box-shadow: 5px 0px 5px #0090f7;">
								<header style="margin-left:10px" >
									<h1>Amer Marei</h1>
									<span class="year"> PhD in Hydrology and hydrochemistry</span><br>
									<span > E: marei@planet.edu</span><br>
									<span class="duration"> T: +972-02-2794191</span>
								</header>
								<p>
Works at Alquds university. supervised on the scientific side of the project.								</p>
							</div>
						</div>
					</li>
					

				
				</ul>
				<hr style="border-top: 1px dashed #3caee6; ">
				<ul class="stage clearfix">
					<li class="scene2" style="margin-right: 120px;">
						<div class="movie" onclick="return true">
							<div class="poster"style="box-shadow: 5px 0px 5px #41ff3e;"></div>
							<div class="info"style="box-shadow: 5px 0px 5px #41ff3e;">
								<header style="margin-left:10px">
									<h1>Mohammed AbuSamaan</h1>
									<span class="year">Programmer</span><br>
									<span >E: mohammed_jouda95@hotmail.com</span><br>
									<span class="duration">T: +970-597026183</span>
								</header>
								<p>
									A student at alquds university. Programmed the project and a leader of the group.
								</p>
							</div>
						</div>
					</li>
					 <li class="scene2"style="margin-left: 120px;">
						<div class="movie" onclick="return true">
							<div class="poster"style="box-shadow: 5px 0px 5px #41ff3e;"></div>
							<div class="info"style="box-shadow: 5px 0px 5px #41ff3e;">
								<header style="margin-left:10px">
									<h1>Zainab Al-sheikh</h1>
									<span class="year">Programmer</span><br>
									<span >E: hotmail.com</span><br>
									<span class="duration">T: +972-02-2799753</span>
								</header>
								<p>
								A student at alquds university. Helped to program the project and made the presentation and decumentation of the project.
								</p>
							</div>
						</div>
					</li>
                 <li class="scene2"style="margin-right: 120px;">
						<div class="movie" onclick="return true">
							<div class="poster" style="box-shadow: 5px 0px 5px #41ff3e;"></div>
							<div class="info"style="box-shadow: 5px 0px 5px #41ff3e;">
								<header style="margin-left:10px">
									<h1>Alaa Al-aqraa</h1>
									<span class="year">Programmer</span><br>
									<span >E: hotmail.com</span><br>
									<span class="duration">T: +972-02-2799753</span>
								</header>
								<p>
								A student at alquds university. Helped to program the project and made the desgin part of the project.
								</p>
							</div>
						</div>
					</li>
					
				<ul>
			</div><!-- /wrapper -->
		</div><!-- /container -->
	  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
     
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Sign In</h4>
        </div>
        <div class="modal-body">
		  
		 <div style="background-color:red; color:white" id="login_msg"> <?php 
		   if(!isset($_SESSION["user_name"])){
			 echo $_SESSION['login_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
          <form id="login_form" method="post">
		 
            <div class="form-group">
              <label for="usrname"  ><span class="glyphicon glyphicon-user"></span> User Name </label>
              <input required="true" name="username" type="text" class="form-control" id="username" placeholder="Enter Username">
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-asterisk"></span> Password </label>
              <input required="true" name="password" type="password" class="form-control" id="password" placeholder="Enter Password">
            </div>
           
              <button type="button" class="btn btn-block" id="login_btn" name="login_btn">Sign In 
                <span class="glyphicon glyphicon-ok"></span>
              </button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal">
            <span class="glyphicon glyphicon-remove"></span> Cancel
          </button>
          <p>Need <a href="#">Sign Up?</a></p>
        </div>
      </div>
    </div>
  </div>
<!-- Container (Contact Section) -->
<div id="contact" class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center"><em>We love our fans!</em></p>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Ramallah, Palestine</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +970 597026183</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
	 
	<form role="form" action="../php/contact_messages.php"  method="post">
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea required="true" class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <br>
	  
      <div class="row">
        <div class="col-md-12 form-group">
          <button id="contact_btn" name="contant_btn" class="btn pull-right" type="button">Send</button>
        </div>
		
      </div>
	   <div style="background-color:red; color:white" id="contact_msg"> <?php 
		    if(isset($_SESSION['contact_error'])){
			 echo $_SESSION['contact_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
	 
    </div>
	</form>
  </div>
 
</div>





<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>WRMapping Project Made By <a href="https://www.alquds.edu" data-toggle="tooltip" title="Visit Alquds Univesity">www.alquds.edu</a></p> 
</footer>

<script src="../js/bootstrap_scripts.js"></script>
<script src="../js/contact.js"></script>
<script src="../js/login.js"></script>
<script src="../js/convert.js"></script>

 
<!-- <script src="../js/logout_timer.js"></script>  -->


</body>
</html>
<?php 
$_SESSION['contact_error']='';
?>
