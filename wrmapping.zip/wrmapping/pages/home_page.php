
<?php 
session_start();
?>
<!DOC<!DOCTYPE html>

<html lang="en">
<head>

  <title>SWMS</title>
  <link rel="icon" href="../images/logo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	 <style>
	 #myVideo {
   
    right: 0;
    bottom: 0;
    min-width: 100%; 
    min-height: 100%;
}
       #map {
        height: 400px;
        width: 100%;
       }
	   #floating-panel {
       
        top: 10px;
        left: 25%;
        
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Roboto','sans-serif';
        line-height: 30px;
        padding-left: 10px;
      }
      
    </style>
 <link rel="stylesheet" href="../css/general_css.css">
</head>
<body id="body" style="background-image:url(http://eltanorthamerica.com/wp-content/uploads/2016/06/stark-bg.gif) ;width:100%;height: 100%;  background-repeat: no-repeat; " data-spy="scroll" data-target=".navbar" data-offset="50">


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid" style=" box-shadow: 0px 5px 5px #888888;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
       <a  href="home_page.php"><img src= "../images/logo.jpg"   width="60" height="60" style="position: fixed;" /></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar" >
 <ul class="nav navbar-nav navbar-right" style="min-height:30px !important">
        <li><a href="home_page.php">HOME</a></li>
       
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">WATER SYSTEM
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="public_map.php">Water Mapping</a></li>
           <li><a href="converter.php">Quality Indicators</a></li>
			<li><a href="spreadsheets.php">Dashboard</a></li>
			<li><?php if(isset($_SESSION["first_name"]) && ($_SESSION["user_type"] == 1)){ echo '<a href="settings.php">Settings</a>';}?> </li>
			<?php 
		 if(isset($_SESSION["first_name"])){
			 echo '<li><a style="background-color:#e007076e" href="../php/logout.php">Logout</a></li>';}
	
		 ?>
          </ul>
        </li>
		<li><a href="investigator.php">INVESTIGTORS</a></li>
		<li><a href="publication.php">PUBLICTOINS</a></li>
		 <li><a href="#about">ABOUT</a></li>
          <li><a href="#contact">CONTACT</a></li>
		
        <li><a style="padding-top: 13px;padding-bottom: 13px;" href="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo '#';}?> " class="btn btn-info btn-lg" data-toggle="modal" data-target="<?php if(isset($_SESSION["first_name"])){echo "../pages/user_page.php" ;} else{ echo "#myModal";}?>"><span class="glyphicon glyphicon-log-in"></span> 
		<?php 
		 if(isset($_SESSION["first_name"])){
			 echo $_SESSION["first_name"] ;}
		 else{ 
		 echo "Login";}
		 ?></a></li>
      </ul>
    </div>
  </div>
</nav>


<video autoplay muted loop id="myVideo">
  <source src="../images/video.mp4" type="video/mp4">
</video>

<!-- Container (The Band Section) -->
<div id="about" class="container text-center">
  <h3>Sustainable Water Management System</h3>
  <p><em>In Palestine</em></p>
  <p>We have created a WRMapping website. Our project aims to help Ministry, farmers and people who live lives in West Bank. It solved the problems that related to quality and quatity of water resources. The project helps to know the water resources in West Bank and accurately identify where the water are, also it helps the farmers to determine the amount of water needed for agriculture.</p>
  <br>
  
</div>
 <div id="myCarousel" class="carousel slide" data-ride="carousel" style=" box-shadow: 0px 0px 30px #888888;">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox" >
      <div class="item active">
        <img src="../images/c1.jpg" alt="New York" style="width:100%; height:100%; !improtant">
        <div class="carousel-caption">
          <h3>Water Quantity</h3>
          <p>Enjoy our maps to know water resources quantity.</p>
        </div>      
      </div>

      <div class="item">
        <img src="../images/c2.jpg" alt="Chicago" style=" width:100%; height:100%; !improtant">
        <div class="carousel-caption">
          <h3>Water Quality</h3>
          <p>Enjoy our maps to know water resources quality.</p>
        </div>      
      </div>
    
      <div class="item">
        <img src="../images/c3.jpg" alt="Los Angeles" style=" width:100%; height:100%; !improtant">
        <div class="carousel-caption">
          <h3>Agriculture</h3>
          <p>Enjoy our maps to surfe agriculture use.</p>
        </div>      
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
 
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
     
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>
          <h4><span class="glyphicon glyphicon-lock"></span> Sign In</h4>
        </div>
        <div class="modal-body">
		  
		 <div style="background-color:red; color:white" id="login_msg"> <?php 
		   if(!isset($_SESSION["user_name"])){
			 echo $_SESSION['login_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
          <form id="login_form" method="post">
		 
            <div class="form-group">
              <label for="usrname"  ><span class="glyphicon glyphicon-user"></span> User Name </label>
              <input required="true" name="username" type="text" class="form-control" id="username" placeholder="Enter Username">
            </div>
            <div class="form-group">
              <label for="psw"><span class="glyphicon glyphicon-asterisk"></span> Password </label>
              <input required="true" name="password" type="password" class="form-control" id="password" placeholder="Enter Password">
            </div>
           
              <button type="button" class="btn btn-block" id="login_btn" name="login_btn">Sign In 
                <span class="glyphicon glyphicon-ok"></span>
              </button>
          </form>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger btn-default pull-left" data-dismiss="modal">
            <span class="glyphicon glyphicon-remove"></span> Cancel
          </button>
          <p>Need <a href="#">Sign Up?</a></p>
        </div>
      </div>
    </div>
  </div>


<!-- Container (Contact Section) -->
<div id="contact" class="container">
  <h3 class="text-center">Contact</h3>
  <p class="text-center"><em>We love our fans!</em></p>

  <div class="row">
    <div class="col-md-4">
      <p>Fan? Drop a note.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Ramallah, Palestine</p>
      <p><span class="glyphicon glyphicon-phone"></span>Phone: +970 597026183</p>
      <p><span class="glyphicon glyphicon-envelope"></span>Email: mail@mail.com</p>
    </div>
	 
	<form role="form" action="../php/contact_messages.php"  method="post">
    <div class="col-md-8">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input required="true" class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea required="true" class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea>
      <br>
	  
      <div class="row">
        <div class="col-md-12 form-group">
          <button id="contact_btn" name="contant_btn" class="btn pull-right" type="button">Send</button>
        </div>
		
      </div>
	   <div style="background-color:red; color:white" id="contact_msg"> <?php 
		    if(isset($_SESSION['contact_error'])){
			 echo $_SESSION['contact_error'] ;}
		 
		 else{ 
		 echo "";}
		 ?></div>
	 
    </div>
	</form>
  </div>
 
</div>

<!-- Add Google Maps, -->

<div id="googleMap"></div>
<script>
function myMap() {
    var myCenter = new google.maps.LatLng(31.919191, 35.2158);
var mapProp = {center:myCenter, zoom:12, scrollwheel:false, draggable:false, mapTypeId:google.maps.MapTypeId.ROADMAP};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
var marker = new google.maps.Marker({position:myCenter});
marker.setMap(map);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCl-DZJeFdTqec7WZjmPfCTHs4xWW-6Ffw&callback=myMap"></script>

<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p>WRMapping Project Made By <a href="https://www.alquds.edu" data-toggle="tooltip" title="Visit Alquds Univesity">www.alquds.edu</a></p> 
</footer>

<script src="../js/bootstrap_scripts.js"></script>
<script src="../js/login.js"></script>
<script src="../js/contact.js"></script>
 <!-- <script src="../js/logout_timer.js"></script> -->



 

</body>
</html>
<?php 
$_SESSION['login_error']='';
$_SESSION['login_error']='';
$_SESSION['contact_error']='';
?>
