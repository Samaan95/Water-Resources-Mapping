  
  function drawFusionmap(locations) {
	  //draw markers
var marker;
var markers = [];
 $("#legend").append('<div class="col-sm-3"> <h5 style="font-size:17px;">Water Resource<img src= "../images/well.png"   width="40" height="40"/></h5></div>');
	 for (i = 0; i < locations.length; i++) {  
	  var infowindow = new google.maps.InfoWindow();
	   marker = new google.maps.Marker({
        position: locations[i]['location'],
        title:locations[i]['wr_name'],
	  icon: {url:'../images/well.png', scaledSize: new google.maps.Size(40, 40)}
      });
	  
     
      google.maps.event.addListener(marker, 'click', (function(marker, i,locations) {
         
		   var plants= new Array();
		   var ecw=0;
		   
		   var ecw_date;
		   var ecw_hazard;
		  $.ajax({
          url : '../php/get_ecw_plant.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   ecw=obj[0][0];
		   
		   ecw_date=obj[0][3];
		   ecw_hazard=obj[0][4];
		   plants[0]=['Plant name', 'Yeild%'];
		   
		   
			for(var i = 0 ; i < obj.length;i++){
			plants[i+1] =[obj[i][1],Number(obj[i][2])];  
          	
         }
		
          }
          });
		  var sar_hazard;
		 $.ajax({
          url : '../php/get_sar_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   sar_hazard=obj[0][0];
		
          }
          });
		   var gys=0;
		   var ecw_targ=0;
		     var plants_exp= new Array();
		   $.ajax({
          url : '../php/calc_gypsum_exp.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   var ecw2=obj[0][0];
		   var ec_from=obj[0][1];
		   if(ecw2 <= ec_from){
			   ecw_targ = ec_from + 0.1;
			   var ecw_add=  ecw_targ - ecw2; 
			   var gys_pure = ecw_add * 640 * 2.7;
			    gys = gys_pure *(100/75);
			  
		   }
		   $.ajax({
          url : '../php/get_ecw_plant_exp.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{ecw_targ:ecw_targ},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		  
		   plants_exp[0]=['Plant name', 'Yeild%'];
		  
		   
			for(var i = 0 ; i < obj.length;i++){
			plants_exp[i+1] =[obj[i][0],Number(obj[i][1])];  
          	
         }
		
          }
          });
          }
          });
		  
		  var Cl;
		  
		  var cl_hazard;
		 
		  var cl_crops;
		 
		  $.ajax({
          url : '../php/get_cl_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    Cl=obj[0][0];
		   cl_hazard=obj[0][1];
		   cl_crops=obj[0][2];
		  
		   
		
          }
          });
		   var b_crops;var B; var b_hazard;
		   $.ajax({
          url : '../php/get_b_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   
		   B=obj[0][0];
		   b_hazard=obj[0][1];
		   b_crops=obj[0][2];
		   
		
          }
          });
		  var ph;
		  var ph_hazard;
		  $.ajax({
          url : '../php/get_ph_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    ph=obj[0][0];
		   ph_hazard=obj[0][1];
		  
          }
          });
		  
		  var rsc;
		  var rsc_hazard;
		  var rsc_class;
		  $.ajax({
          url : '../php/get_rsc_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    rsc=obj[0][2];
		   rsc_hazard=obj[0][1];
		   rsc_class=obj[0][0];
		  
          }
          });
		   var no3;
		  var no3_hazard;
		 
		  $.ajax({
          url : '../php/get_no3_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		 
		   no3_hazard=obj[0][0];
		   no3=obj[0][1];
		  
          }
          });
		  var related_farms=[];
		  $.ajax({
          url : '../php/get_related_farms.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		 
		 for(var i = 0 ; i < obj.length;i++){
			
          	related_farms[i]=[obj[i][0],obj[i][1],obj[i][2]];
         }
		  
          }
          });
		  // consumption
		  
		   var prodcons_year=[];
		   var pie_cons_year=[];
		   $.ajax({
           url : '../php/get_prodcons_year_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_year[0]=['Year', 'Water Quanity', 'Agriculture' , 'Population'];
		   
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_year[i+1] =[obj[i][0],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		 pie_cons_year[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_year[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_year[2]=['Population',Number(obj[1][3])];
		 
          }
          });
		   var prodcons_month=[];
		   var pie_cons_month=[];
		   $.ajax({
           url : '../php/get_prodcons_month_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_month[0]=['Month', 'Water Quanity', 'Agriculture' , 'Population' ];
		   
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_month[i+1] =[obj[i][0]+'-'+obj[i][1],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
			 
		  }
		  pie_cons_month[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_month[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_month[2]=['Population',Number(obj[1][3])];
          }
          });
		   var prodcons_season=[];
		    var pie_cons_season=[];
		   $.ajax({
           url : '../php/get_prodcons_season_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:locations[i]['wr_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_season[0]=['Season', 'Water Quanity', 'Agriculture' , 'Population'];
		   
			for(var i = 0 ; i < obj.length;i++){
			 
			 prodcons_season[i+1] =[obj[i][1]+'('+obj[i][0]+')',Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		  
		  pie_cons_season[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_season[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_season[2]=['Population',Number(obj[1][3])];
          }
          });
		 
        return function() {
		  
		   var content='<div class="tab">'+
		  '<button id="b1" class="tablinks" onclick="openCity(event,`quality`)" >Quality</button>'+
		  '<button id="b2" class="tablinks" onclick="openCity(event,`quantity`)">Consumption</button>'+
		  '</div>'+
		  '<div id="quality" class="tabcontent">'+
		  '<div style="box-shadow: 0px 10px 5px #888888;"><h3>Water Suitability Mapping</h3></div>'+
		  
		   '<div class="panel panel-primary">'+
     ' <div class="panel-heading">'+locations[i]['wr_name']+'</div>'+
     ' <div class="panel-body" >'+
	' <div class="row">'+
  '<div class="col-sm-6">'+
    '<h5 style="color:black; padding-left:4%;"><u><strong>Water Resource Info</u></strong></h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Type: </strong>'+locations[i]['type']+'</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Address: </strong>'+locations[i]['region_name']+', '+locations[i]['city_name']+'</h5>'+
		  '<h5 style="color:black; padding-left:4%; padding-bottom:1%"><strong>Coordinates: </strong>'+Number(locations[i]['x']).toFixed(4)+', '+Number(locations[i]['y']).toFixed(4)+'</h5>'+
  '</div>'+
 ' <div  id="relatedFarms" class="col-sm-6"  >'+
  '<h5 style="color:black; padding-left:4%;"><strong><u>Related Farms</u></strong></h5>'+
		
 ' </div>'+
'</div>'+
	
	 ' </div>'+
   ' </div>'+
            '<img id="ecwAlert"  width="30" height="30"/>'+
			'<a href="http://www.fao.org/docrep/003/T0234E/T0234E03.htm#3note5" style="margin-left:20px">FAO Standards</a>'+
            '<h5 style="font-size: 15px;text-decoration: underline"><strong>Salinity</strong></h5>'+
		  '<div><strong>ECw:</strong> '+ecw+' dS/m <br><strong> Date:</strong> '+ecw_date+'<br>'+ecw_hazard+'</div>'+
		  
            '<div id="chart_div" ></div><hr>'+
			 '<img id="sarAlert"  width="30" height="30"/>'+
			 '<h5 style="font-size: 15px;text-decoration: underline"><strong>Infiltration</strong></h5>'+
		  '<div><strong>Risk of water infiltration problem:</strong> <strong style="color:#0061b7">'+sar_hazard+'</strong><br>*The higher the SAR, the greater the risk of damaging soil structure'+'<br>'+'To avoid the water infiltration problem, need to add <Strong style="background-color:#dff0d8">'+gys+'</Strong> lb of 75% pure gypsum/acre-ft , upon the addition ECw would be <Strong style="background-color:#dff0d8">'+ecw_targ+'</Strong> dS/m. </div>'+
		 
		   '<div id="chart_div_exp" ></div><hr>'+
		   
		   '<h5 style="font-size: 15px;text-decoration: underline"><strong>Specific Ion Toxicity</strong></h5>'+
		   '<img id="clAlert"  width="30" height="30"/>'+
		   '<div><strong>Risk of Chloride: '+Cl+' mg/L </strong> <strong style="color:#0061b7">'+cl_hazard+'</strong><br>'+'The recommended crops: '+cl_crops+'</div>'+
		   '<img id="bAlert"  width="30" height="30"/>'+
		   '<div><strong>Risk of Boron: '+B+' mg/L </strong> <strong style="color#0061b7">'+b_hazard+'</strong><br>'+'The recommended crops: '+b_crops+'</div>'+
		   '<hr><h5 style="font-size: 15px;text-decoration: underline"><strong>Miscellaneous Effects</strong></h5>'+
		   '<img id="phAlert"  width="30" height="30"/>'+
		   '<div><strong>pH: '+ph+' </strong><strong style="color:#0061b7"> '+ph_hazard+'</strong></div>'+
		    '<img id="rscAlert"  width="30" height="30"/>'+
		   '<div><strong>Risk of Residual sodium carbonate (RSC) : '+rsc+' </strong><strong style="color:#0061b7"> '+rsc_class+'</strong><br>*'+rsc_hazard+'</div>'+
		  '<img id="no3Alert"  width="30" height="30"/>'+
		   '<div><strong>Risk of Nitrogen (NO3 - N) : '+no3+' </strong><strong style="color:#0061b7"> '+no3_hazard+'</strong></div><br>'+
		  '</div>'+
		  '<div id="quantity" class="tabcontent">'+
		  '<div style="box-shadow: 0px 10px 5px #888888;"><h3>Water Consumption Mapping</h3></div>'+
		 '<div class="panel panel-primary">'+
     ' <div class="panel-heading">'+locations[i]['wr_name']+'</div>'+
     ' <div class="panel-body" >'+
	  ' <div class="row">'+
  '<div class="col-sm-6">'+
    '<h5 style="color:black; padding-left:4%;"><strong><u>Water Resource Info</u></strong></h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Type: </strong>'+locations[i]['type']+'</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Address: </strong>'+locations[i]['region_name']+', '+locations[i]['city_name']+'</h5>'+
		  '<h5 style="color:black; padding-left:4%; padding-bottom:1%"><strong>Coordinates: </strong>'+Number(locations[i]['x']).toFixed(4)+', '+Number(locations[i]['y']).toFixed(4)+'</h5>'+
  '</div>'+
 ' <div id="relatedFarms2" class="col-sm-6">'+
  '<h5 style="color:black; padding-left:4%;"><strong><u>Related Farms</u> </strong> </h5>'+
		 
 ' </div>'+
'</div>'+
	 ' </div>'+
   ' </div>'+
		 
		  '<h5 style="font-size: 15px;text-decoration: underline"><strong>General Consumption</strong></h5>'+
		   '<div id="chart_div_dev_month" ></div>'+
		   '<div id="piechartMonth" ></div><hr>'+
		   '<div id="chart_div_dev_year" ></div>'+
		   '<div id="piechartYear" ></div><hr>'+
		   '<div id="chart_div_dev_season" ></div>'+
		   '<div id="piechartSeason" ></div><hr>'+
		    
		  '</div>'; 
		 
		
          infowindow.setContent(content);
          infowindow.open(map, marker);
		  printRelatedFarms(related_farms);
		 drawPlants(plants); 
		   drawPlantsExp(plants_exp);
		  drawHazardpH(ph_hazard);
		  drawHazardRsc( rsc_class);
		  drawHazardNo3( no3_hazard);
		   drawHazardB( b_hazard); 
		   drawHazardEcw(ecw_hazard);drawHazardCl(cl_hazard);
		  drawHazardSar(sar_hazard);
		   
		   drawDevYear(prodcons_year);
		drawDevMonth(prodcons_month);
		drawDevSeason(prodcons_season);
		drawPieMonth(pie_cons_month);
		drawPieYear(pie_cons_year);
		drawPieSeason(pie_cons_season);
	     
		
		
        }
      })(marker, i,locations));
	   markers.push(marker);
	
    }
	   google.maps.event.addListener(map, 'zoom_changed', function() {
var zoom = map.getZoom();
if(zoom >= 14){
		  
      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
}
else{
	      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(null);
       
    }
}
});
	
	
	
  }
 function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
 function printRelatedFarms(data){

	   for(var i = 0 ; i < data.length;i++){
		     
			    $("#relatedFarms").append('<li><strong>'+data[i][0]+', '+data[i][1]+', '+data[i][2]+'.</strong></li>');
	              $("#relatedFarms2").append('<li><strong>'+data[i][0]+', '+data[i][1]+', '+data[i][2]+'.</strong></li>');
		  }
	   
   }
		function drawPlants(data) {
			 //var data = google.visualization.arrayToDataTable(data2,false);
        // Some raw data (not necessarily accurate)
		
        var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       
 
    var options = {
		 
		width:500, 
		height: 400,
      title : 'Plant yeild depending on ECw',
      vAxis: { },
      hAxis: {title: 'Yeild%' ,viewWindow: { max:100,min:0}},
	  legend: 'none',
	  
	    bars: 'horizontal'
	   
    };
	 
    var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
    chart.draw(table, options);
  }
  function drawPlantsExp(data) {
			
		
        var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       
 
    var options = {
		 
		width:500, 
		height: 400,
      title : 'Plant yeild depending on the new ECw',
      vAxis: { },
      hAxis: {title: 'Yeild%' ,viewWindow: { max:100,min:0}},
	  legend: 'none',
	  
	    bars: 'horizontal'
	   
    };
	 
    var chart = new google.visualization.BarChart(document.getElementById('chart_div_exp'));
    chart.draw(table, options);
  }
  
  function drawHazardSar(sar_hazard) {
          
		  if(sar_hazard=="High"){$("#sarAlert").attr("src","../images/no.gif" );}
		   if( sar_hazard=="Moderate"){$("#sarAlert").attr("src","../images/mid.png" );}
		 if(sar_hazard=="Low"){$("#sarAlert").attr("src","../images/yes.png" );}
		 
		
		}
		 function drawHazardpH(ph_hazard) {
			 if(ph_hazard=="Low Range"||ph_hazard=="High Range"){$("#phAlert").attr("src","../images/no.gif" );}
		if(ph_hazard=="Normal Range"){$("#phAlert").attr("src","../images/yes.png" );}
		 }
		 function drawHazardEcw( ecw_hazard) {
			 
			  ecw_hazard = ecw_hazard.split("."); 
		 if(ecw_hazard[0]=="High hazard"){$("#ecwAlert").attr("src","../images/no.gif" );}
		   if( ecw_hazard[0]=="Medium hazard"|| ecw_hazard[0]=="Medium-high hazard"){$("#ecwAlert").attr("src","../images/mid.png" );}
		 if(ecw_hazard[0]=="Very low hazard"|| ecw_hazard[0]=="Low hazard"){$("#ecwAlert").attr("src","../images/yes.png" );}
		
		 }
		 function drawHazardB( b_hazard) {
			  if(b_hazard=="Tolerant"||b_hazard=="Very tolerant"){$("#bAlert").attr("src","../images/no.gif" );}
		   if( b_hazard=="Moderately sensitive"|| b_hazard=="Moderately tolerant"){$("#bAlert").attr("src","../images/mid.png" );}
		if(b_hazard=="Extremely sensitive"|| b_hazard=="Very sensitive"|| b_hazard=="Sensitive"){$("#bAlert").attr("src","../images/yes.png" );}
          
		 }
		 function drawHazardCl( cl_hazard) {
			 if(cl_hazard=="Can cause severe problems"){$("#clAlert").attr("src","../images/no.gif" );}
		   if( cl_hazard=="Moderately sensitive plants"){$("#clAlert").attr("src","../images/mid.png" );}
		 if(cl_hazard=="Safe for most plants" || cl_hazard=="Sensitive plants" ){$("#clAlert").attr("src","../images/yes.png" );}
	   
		 }
		 function drawHazardRsc( rsc_hazard) {
			 if(rsc_hazard=="High" || rsc_hazard=="Very high"){$("#rscAlert").attr("src","../images/no.gif" );}
		   if( rsc_hazard=="Medium"){$("#rscAlert").attr("src","../images/mid.png" );}
		 if(rsc_hazard=="Low"){$("#rscAlert").attr("src","../images/yes.png" );}
	   
		 }
		  function drawHazardNo3( no3_hazard) {
			 if(no3_hazard=="High"){$("#no3Alert").attr("src","../images/no.gif" );}
		   if( no3_hazard=="Moderate"){$("#no3Alert").attr("src","../images/mid.png" );}
		 if(no3_hazard=="Low"){$("#no3Alert").attr("src","../images/yes.png" );}
	   
		 }
 function drawDevYear(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Year',
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
		   vAxis: {title: '',  titleTextStyle: {color: '#333'}}
      
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_year'));
        chart.draw(table, options);
      }
	  function drawDevMonth(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Month',
          hAxis: {title: 'Month',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_month'));
        chart.draw(table, options);
      }
	   function drawDevSeason(data) {
		   
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Season',
          hAxis: {title: 'Season',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_season'));
        chart.draw(table, options);
      }
	  function drawPieMonth(data){
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
          title: "Previous Month Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartMonth'));

        chart.draw(table, options);
  }
	  function drawPieYear(data){
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
          title: "Previous Year Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartYear'));

        chart.draw(table, options);
  }
   function drawPieSeason(data){
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
          title: "Previous Season Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartSeason'));

        chart.draw(table, options);
  }