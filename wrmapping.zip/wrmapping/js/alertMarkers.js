function drawFusionmapAlert(locations) {
	  //draw markers
var marker;
var markers = [];
	 for (i = 0; i < locations.length; i++) {  
	  var infowindow = new google.maps.InfoWindow();
	   marker = new google.maps.Marker({
        position: locations[i]['location'],
        optimized:false,
	  //icon: {url:'http://www.showroomdecoracion.es/wordpress/wp-content/uploads/2013/08/maps_marker.png', scaledSize: new google.maps.Size(70, 60)}https://venuehire.spacecentre.co.uk/wp-content/themes/nsc-creative/img/loading.gif
	  icon: {url:'https://media.giphy.com/media/lSplQ34LvgEX6/giphy.gif', scaledSize: new google.maps.Size(40, 40)}
      });
	  
     
     
      google.maps.event.addListener(marker, 'click', (function(marker, i,locations) {
        return function() {
			
          infowindow.setContent('<div><strong>'+locations[i]['location']+'</strong><br>');
          infowindow.open(map, marker);
        }
      })(marker, i,locations));
	   markers.push(marker);
	
    }
	 for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
	   google.maps.event.addListener(map, 'zoom_changed', function() {
var zoom = map.getZoom();

		  
      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
      
});
	
  }   