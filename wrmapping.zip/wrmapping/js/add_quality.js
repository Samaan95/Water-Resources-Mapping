  
  var selected_city;
  var selected_region;
 
  var selected_wr;

  $.ajax({
       url : '../php/city.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
         $("#sel1").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
	
	document.getElementById("sel1").addEventListener("change", function(){
		selected_city = $("#sel1" ).val();
		
		 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
		 $('#sel2')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/region_selected.php', 
	   data:{city_id: selected_city},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel2").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	document.getElementById("sel2").addEventListener("change", function(){
		selected_region = $("#sel2" ).val();
		 
		 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/wr_selected.php', 
	   data:{region_id: selected_region},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel3").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	document.getElementById("sel3").addEventListener("change", function(){
		
		selected_wr = $("#sel3" ).val();
		
		  
		 
	}
	);
$(document).ready(function(){
	 $('#na').keyup(function(event) {
       $('#sar').val( $('#na').val()/Math.sqrt(($('#ca').val()+ $('#mg').val())/2));
         
});
 $('#ca').keyup(function(event) {
       $('#sar').val( $('#na').val()/Math.sqrt(($('#ca').val()+ $('#mg').val())/2));
         
});
$('#mg').keyup(function(event) {
       $('#sar').val( $('#na').val()/Math.sqrt(($('#ca').val()+ $('#mg').val())/2));
         
});
	 $("#add_btn").click(function(){	
	
		    var wr_id=$("#sel3").val();
			var ec=$("#ec").val();
			var na=$("#na").val();
				var ca=$("#ca").val();
					var mg=$("#mg").val();
						var sar=$("#sar").val();
							var b=$("#b").val();
								var cl=$("#cl").val();
									var hco=$("#hco").val();
										var no=$("#no").val();
											var so=$("#so").val();
												var ph=$("#ph").val();
													var co=$("#co").val();
			var getdate= new Date($("#date").val());
			var date=getdate.getFullYear()+"-"+(getdate.getMonth()+1)+"-"+getdate.getUTCDate();
		
			
		  if($.trim(wr_id).length>0 && $.trim(date).length>0){
			 
			
			  $.ajax({
		   type: "POST",
		   url: "../php/add_quality.php",
			data:{wr_id:wr_id,ec:ec,na:na,ca:ca,mg:mg,sar:sar,b:b,cl:cl,hco:hco,no:no,so:so,ph:ph,co:co,date:date},
		    success: function(data){    
		   if(data){
			  
			   $("#add_msg").html("<div class='alert alert-success alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong></div>");
		   }
		  
			else{
		    $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: Wrong Data!</strong></div>");
			  
			
			  }}
			});
			  
		  }
		  else{
			 if($.trim(wr_id).length== 0 || $.trim(date).length==0){
				 
				 $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: complete fields!</strong></div>");
				
			 }
				 
			
		  }
	});
});