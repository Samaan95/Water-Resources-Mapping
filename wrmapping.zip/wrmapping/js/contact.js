$(document).ready(function(){
	$('#name').on('input', function() {
	var input=$(this);
	var is_name=input.val();
	if(is_name){input.removeClass("invalid").addClass("valid");}
	else{input.removeClass("valid").addClass("invalid");}
});
$('#email').on('input', function() {
	var input=$(this);
	var is_name=input.val();
	if(is_name){input.removeClass("invalid").addClass("valid");}
	else{input.removeClass("valid").addClass("invalid");}
});
$('#comments').keyup(function(event) {
	var input=$(this);
	var message=$(this).val();
	console.log(message);
	if(message){input.removeClass("invalid").addClass("valid");}
	else{input.removeClass("valid").addClass("invalid");}	
});
	 $("#contact_btn").click(function(){	
		   var name=$("#name").val();
		   var email=$("#email").val();
		    var comments=$("#comments").val();
			 var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		  if($.trim(name).length>0 && $.trim(email).length>0 &&$.trim(comments).length>0 && re.test(email)){
			 
			
			  $.ajax({
		   type: "POST",
		   url: "../php/contact_messages.php",
			data:{name:name,email:email,comments:comments},
			cache:false,
		    success: function(data){    
		   if(data==true){
			  
			  $("#contact_msg").load(location.href + " #contact_msg");
		   }
		  
			else{
		    // $("#contact_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: wrong eamil!</strong></div>");
			  //$("#contact_msg").load(location.href + " #contact_msg");
			
			  }}
			});
			  
		  }
		  else{
			 if($.trim(name).length== 0 || $.trim(email).length== 0 || $.trim(comments).length==0){
				 
				 $("#contact_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: complete fields!</strong></div>");
				
			 }
				 else if(!re.test(email)){
		    $("#contact_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: wrong email!</strong></div>");
			
			$('#email').addClass("invalid");
				
				 }
			
	             
				  
			
         
			 
		  }
	});
});

