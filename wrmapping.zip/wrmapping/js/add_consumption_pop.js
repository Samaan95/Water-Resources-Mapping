  
  var selected_city;
  var selected_region;
  var selected_pop;
   var selected_wr;
  
  $.ajax({
       url : '../php/city.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
         $("#sel1").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
	
	document.getElementById("sel1").addEventListener("change", function(){
		selected_city = $("#sel1" ).val();
		
		 $('#sel2')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $('#sel4')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/region_selected.php', 
	   data:{city_id: selected_city},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel2").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	document.getElementById("sel2").addEventListener("change", function(){
		selected_region = $("#sel2" ).val();
		 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $('#sel4')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
		 $.ajax({
       url : '../php/get_pops.php', // my php file
	   data:{region:selected_region},
       type : 'POST', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][0];
          var name = obj[i][1]+"-"+obj[i][2];
         $("#sel3").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
		$.ajax({
       url : '../php/wr_selected.php', 
	   data:{region_id: selected_region},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel4").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });

	}
	);
	document.getElementById("sel3").addEventListener("change", function(){
		selected_pop = $("#sel3" ).val();
		
		

	}
	);
	document.getElementById("sel4").addEventListener("change", function(){
		
		selected_wr = $("#sel4" ).val();
		
		  
		 
	}
	);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	$(document).ready(function(){
	
	 $("#add_btn").click(function(){	
		    var pop=$("#sel3").val();
			  var wr=$("#sel4").val();
			var consumption=$("#consumption").val();
			var getdate= new Date($("#date").val());
			var date=getdate.getFullYear()+"-"+(getdate.getMonth()+1)+"-"+getdate.getUTCDate();
			var season;
			if((getdate.getMonth()+1)==1 ||(getdate.getMonth()+1)==2||(getdate.getMonth()+1)==3){
				season='winter';
			}
			if((getdate.getMonth()+1)==4 ||(getdate.getMonth()+1)==5||(getdate.getMonth()+1)==6){
				season='spring';
			}
			if((getdate.getMonth()+1)==7 ||(getdate.getMonth()+1)==8||(getdate.getMonth()+1)==9){
				season='summer';
			}
			if((getdate.getMonth()+1)==10 ||(getdate.getMonth()+1)==11||(getdate.getMonth()+1)==12){
				season='fall';
			}
		  if($.trim(wr).length>0 &&$.trim(pop).length>0 && $.trim(consumption).length>0&& $.trim(date).length>0&& $.trim(season).length>0){
			 
			
			  $.ajax({
		   type: "POST",
		   url: "../php/add_consumption_pop.php",
			data:{wr_id:wr, pop:pop,consumption:consumption,date:date,season:season},
		    success: function(data){    
		   if(data){
			  
			   $("#add_msg").html("<div class='alert alert-success alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong></div>");
		   }
		  
			else{
		    $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: Wrong Data!</strong></div>");
			  
			
			  }}
			});
			  
		  }
		  else{
			 if($.trim(wr).length== 0 ||$.trim(pop).length== 0 || $.trim(consumption).length== 0 || $.trim(date).length==0|| $.trim(season).length==0){
				 
				 $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: complete fields!</strong></div>");
				
			 }
				 
			
		  }
	});
});


	

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	