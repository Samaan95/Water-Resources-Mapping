    $('#ca_ppm').keyup(function(event) {
       $('#ca_meq').val( $('#ca_ppm').val()/20);
         
});
 $('#ca_meq').keyup(function(event) {
        $('#ca_ppm').val( $('#ca_meq').val()*20);
         
});
 $('#mg_ppm').keyup(function(event) {
       $('#mg_meq').val( $('#mg_ppm').val()/12.2);
         
});
 $('#mg_meq').keyup(function(event) {
        $('#mg_ppm').val( $('#mg_meq').val()*12.2);
         
});
$('#na_ppm').keyup(function(event) {
       $('#na_meq').val( $('#na_ppm').val()/23);
         
});
 $('#na_meq').keyup(function(event) {
        $('#na_ppm').val( $('#na_meq').val()*23);
         
});
$('#k_ppm').keyup(function(event) {
       $('#k_meq').val( $('#k_ppm').val()/39.1);
         
});
 $('#k_meq').keyup(function(event) {
        $('#k_ppm').val( $('#k_meq').val()*39.1);
         
});
$('#cl_ppm').keyup(function(event) {
       $('#cl_meq').val( $('#cl_ppm').val()/35.5);
         
});
 $('#cl_meq').keyup(function(event) {
        $('#cl_ppm').val( $('#cl_meq').val()*35.5);
         
});
$('#co3_ppm').keyup(function(event) {
       $('#co3_meq').val( $('#co3_ppm').val()/30);
         
});
 $('#co3_meq').keyup(function(event) {
        $('#co3_ppm').val( $('#co3_meq').val()*30);
         
});
$('#HCO3_ppm').keyup(function(event) {
       $('#HCO3_meq').val( $('#HCO3_ppm').val()/61);
         
});
 $('#HCO3_meq').keyup(function(event) {
        $('#HCO3_ppm').val( $('#HCO3_meq').val()*61);
         
});
$('#SO4_ppm').keyup(function(event) {
       $('#SO4_meq').val( $('#SO4_ppm').val()/48);
         
});
 $('#SO4_meq').keyup(function(event) {
        $('#SO4_ppm').val( $('#SO4_meq').val()*48);
         
});
$('#SO4-S_ppm').keyup(function(event) {
       $('#SO4-S_meq').val( $('#SO4-S_ppm').val()/32.1);
         
});
 $('#SO4-S_meq').keyup(function(event) {
        $('#SO4-S_ppm').val( $('#SO4-S_meq').val()*32.1);
         
});
$('#NO3_ppm').keyup(function(event) {
       $('#NO3_meq').val( $('#NO3_ppm').val()/62);
         
});
 $('#NO3_meq').keyup(function(event) {
        $('#NO3_ppm').val( $('#NO3_meq').val()*62);
         
});
$('#NO3-N_ppm').keyup(function(event) {
       $('#NO3-N_meq').val( $('#NO3-N_ppm').val()/14);
         
});
 $('#NO3-N_meq').keyup(function(event) {
        $('#NO3-N_ppm').val( $('#NO3-N_meq').val()*14);
         
});
$('#b_ppm').keyup(function(event) {
       $('#b_meq').val( $('#b_ppm').val()/10.8);
         
});
 $('#b_meq').keyup(function(event) {
        $('#b_ppm').val( $('#b_meq').val()*10.8);
         
});
$( "#button_sar" ).click(function() {
    $('#sar_meq').val($('#na_sar_meq').val()/Math.sqrt(($('#ca_sar_meq').val()+ $('#mg_sar_meq').val())/2));
	
});
$('#ec_1').keyup(function(event) {
       $('#ec_11').val( $('#ec_1').val()/640);
         
});
 $('#ec_11').keyup(function(event) {
        $('#ec_1').val( $('#ec_11').val()*640);
         
});
$('#ec_2').keyup(function(event) {
       $('#ec_22').val( $('#ec_2').val()/1);
         
});
 $('#ec_22').keyup(function(event) {
        $('#ec_2').val( $('#ec_22').val()*1);
         
});
$('#ec_3').keyup(function(event) {
       $('#ec_33').val( $('#ec_3').val()/1000);
         
});
 $('#ec_33').keyup(function(event) {
        $('#ec_3').val( $('#ec_33').val()*1000);
         
});