  
  var selected_city;
  var selected_region;
   var city_name;
  var region_name;
  var selected_wr;
   var wr_name;
  var wr_coord;
  $.ajax({
       url : '../php/city.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
         $("#sel1").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
	
	document.getElementById("sel1").addEventListener("change", function(){
		selected_city = $("#sel1" ).val();
		 city_name= $("#sel1 option:selected").text();
		 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
		 $('#sel2')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/region_selected.php', 
	   data:{city_id: selected_city},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel2").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	document.getElementById("sel2").addEventListener("change", function(){
		selected_region = $("#sel2" ).val();
		 region_name= $("#sel2 option:selected").text();
		 $('#sel3')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/wr_selected.php', 
	   data:{region_id: selected_region},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
          
 
         $("#sel3").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	
	document.getElementById("sel3").addEventListener("change", function(){
		 $("#qual1").html("");
		 $("#qual2").html("");
		  $("#chart_div_dev_year").html("");
		 $("#chart_div_dev_month").html("");
		  $("#chart_div_dev_season").html("");
		 $("#piechartMonth").html("");
		  $("#piechartYear").html("");
		 $("#piechartSeason").html("");
	
		selected_wr = $("#sel3" ).val();
		wr_name= $("#sel3 option:selected").text();
			$.ajax({
       url : '../php/wr_selected_coord.php', 
	   data:{region_id: selected_wr},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          
          var x = Number(obj[0][0]).toFixed(4);
          var y = Number(obj[0][1]).toFixed(4);
          wr_coord= x+', '+y;
 
        
		  
		 
        
       }
    });
		 
		  $("#city").html("City: "+city_name);
		  $("#region").html("Region: "+region_name);
	     $("#wr").html("Resource Name: "+wr_name);
		  $("#coord").html("Coordination: "+wr_coord);
		  $("#city2").html("City: "+city_name);
		  $("#region2").html("Region: "+region_name);
	     $("#wr2").html("Resource Name: "+wr_name);
		  $("#coord2").html("Coordination: "+wr_coord);
		      
		  
		  // draw
		   //quality
		   var plants= new Array();
		   var ecw=0;
		 
		   var ecw_date;
		   var ecw_hazard;
		  $.ajax({
          url : '../php/get_ecw_plant.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   ecw=obj[0][0];
		   
		   ecw_date=obj[0][3];
		   ecw_hazard=obj[0][4];
		   plants[0]=['Plant name', 'Yeild%'];
		   
		   
			for(var i = 0 ; i < obj.length;i++){
			plants[i+1] =[obj[i][1],Number(obj[i][2])];  
          	
         }
		 $("#ecw_content").html("");
		  $("#qual1").append('<div id="chart_div" ></div>'
            );
		 $("#ecw_content").append('<td><img id="ecwAlert"  width="30" height="30"/></td>'+
            '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Salinity</strong></h5></td>'+
		  '<td><strong>ECw:</strong> '+ecw+' dS/m <br><strong> Date:</strong> '+ecw_date+'<br>'+ecw_hazard+'</td>'
            );
			 drawPlants(plants); drawHazardEcw(ecw_hazard);
          }
          });
		    var gys=0;
		   var ecw_targ=0;
		    var sar_hazard;
		 $.ajax({
          url : '../php/get_sar_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   sar_hazard=obj[0][0];
		 
          }
          });
		 
		     var plants_exp= new Array();
		   $.ajax({
          url : '../php/calc_gypsum_exp.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   var ecw2=Number(obj[0][0]);
		   var ec_from=Number(obj[0][1]);
		   if(ecw2 <= ec_from){
			   ecw_targ = Number(ec_from) + 0.1;
			   var ecw_add=  ecw_targ - ecw2; 
			   var gys_pure = ecw_add * 640 * 2.7;
			    gys = gys_pure *(100/75);
			  
		   }
		   
		   $.ajax({
          url : '../php/get_ecw_plant_exp.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{ecw_targ:Number(ecw_targ)},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		  
		   plants_exp[0]=['Plant name', 'Yeild%'];
		  
		   
			for(var i = 0 ; i < obj.length;i++){
			plants_exp[i+1] =[obj[i][0],Number(obj[i][1])];  
          	
         }
		   $("#sar_content").html("");
		   $("#qual2").append('<div id="chart_div_exp" ></div>'
            );
		 $("#sar_content").append( '<td><img id="sarAlert"  width="30" height="30"/></td>'+
			 '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Infiltration</strong></h5></td>'+
		  '<td><strong>Risk of water infiltration problem:</strong> <strong style="color:#0061b7">'+sar_hazard+'</strong><br>*The higher the SAR, the greater the risk of damaging soil structure'+'<br>'+'To avoid the water infiltration problem, need to add <Strong style="background-color:#91ff91">'+gys.toFixed(2)+'</Strong> lb of 75% pure gypsum/acre-ft , upon the addition ECw would be <Strong style="background-color:#91ff91">'+ecw_targ+'</Strong> dS/m.</td>'
		   );
		
		drawPlantsExp(plants_exp); drawHazardSar(sar_hazard); 
          }
          });
		  
		  
          }
          });
		  
		  var Cl;
		  var B;
		  var cl_hazard;
		  var b_hazard;
		  var cl_crops;
		  var b_crops;
		  $.ajax({
          url : '../php/get_cl_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    Cl=obj[0][0];
		   cl_hazard=obj[0][1];
		   cl_crops=obj[0][2];
		  $("#cl_content").html("");
		 $("#cl_content").append('<td><img id="clAlert"  width="30" height="30"/></td>'+
		  '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Chloride</strong></h5><h5 style="font-size: 13px;text-decoration: underline"><strong>Specific Ion Toxicity</strong></h5></td>'+
		   '<td><strong>Risk of Chloride: '+Cl+' mg/L </strong> <strong style="color:#0061b7">'+cl_hazard+'</strong><br>'+'The recommended crops: '+cl_crops+'</td>'
		    );
		   drawHazardCl( cl_hazard);
		
          }
          });
		   $.ajax({
          url : '../php/get_b_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		   
		   B=obj[0][0];
		   b_hazard=obj[0][1];
		   b_crops=obj[0][2];
		   $("#b_content").html("");
		 $("#b_content").append( '<td><img id="bAlert"  width="30" height="30"/></td>'+
		   '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Boron</strong></h5><h5 style="font-size: 13px;text-decoration: underline"><strong>Specific Ion Toxicity</strong></h5></td>'+
		  '<td><strong>Risk of Boron: '+B+' mg/L </strong> <strong style="color:#0061b7">'+b_hazard+'</strong><br>'+'The recommended crops: '+b_crops+'</td>'
		   );
		 drawHazardB( b_hazard);
		   
          }
          });
		  var ph=0;
		  var ph_hazard=0;
		  $.ajax({
          url : '../php/get_ph_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    ph=obj[0][0];
		   ph_hazard=obj[0][1];
		    $("#ph_content").html("");
		 $("#ph_content").append('<td><img id="phAlert"  width="30" height="30"/></td>'+
		 		   '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>pH</strong></h5><h5 style="font-size: 13px;text-decoration: underline"><strong>Miscellaneous Effects</strong></h5></td>'+

		   '<td><strong>pH: '+ph+' </strong><strong style="color:#0061b7"> '+ph_hazard+'</strong></td>'
		     ); drawHazardpH(ph_hazard);
          }
          });
		  
		  var rsc;
		  var rsc_hazard;
		  var rsc_class;
		  $.ajax({
          url : '../php/get_rsc_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		    rsc=obj[0][2];
		   rsc_hazard=obj[0][1];
		   rsc_class=obj[0][0];
		    $("#rsc_content").html("");
		 $("#rsc_content").append( '<td><img id="rscAlert"  width="30" height="30"/></td>'+
		 '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Residual sodium carbonate (RSC)</strong></h5><h5 style="font-size: 13px;text-decoration: underline"><strong>Miscellaneous Effects</strong></h5></td>'+
		   '<td><strong>Risk of Residual sodium carbonate (RSC) : '+rsc+' </strong><strong style="color:#0061b7"> '+rsc_class+'</strong><br>*'+rsc_hazard+'</td>'
		  );
		 
		  drawHazardRsc( rsc_class);
	
          }
          });
		   var no3;
		  var no3_hazard;
		 
		  $.ajax({
          url : '../php/get_no3_hazard.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		 
		   no3_hazard=obj[0][0];
		   no3=obj[0][1];
		    $("#no3_content").html("");
		 $("#no3_content").append( '<td><img id="no3Alert"  width="30" height="30"/></td>'+
		 		 '<td><h5 style="font-size: 15px;text-decoration: underline"><strong>Nitrogen (NO3-N)</strong></h5><h5 style="font-size: 13px;text-decoration: underline"><strong>Miscellaneous Effects</strong></h5></td>'+

		   '<td><strong>Risk of Nitrogen (NO3-N) : '+no3+' </strong><strong style="color:#0061b7"> '+no3_hazard+'</strong></td>' );	
		   drawHazardNo3( no3_hazard);
          }
          });
		  var related_farms=[];
		  $.ajax({
          url : '../php/get_related_farms.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
		 
		 for(var i = 0 ; i < obj.length;i++){
			
          	related_farms[i]=[obj[i][0],obj[i][1],obj[i][2]];
         }
		  
          }
          });
		  
		  // consumption
		  
           var prodcons_year=[];
		   var pie_cons_year=[];
		   $.ajax({
           url : '../php/get_prodcons_year_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
          
            prodcons_year[0]=['Year', 'Water Quanity', 'Agriculture' , 'Population'];
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_year[i+1] =[obj[i][0],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		 pie_cons_year[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_year[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_year[2]=['Population',Number(obj[1][3])];
		   drawDevYear(prodcons_year);drawPieYear(pie_cons_year);
          }
          });
		   var prodcons_month=[];
		   var pie_cons_month=[];
		   $.ajax({
           url : '../php/get_prodcons_month_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_month[0]=['Month', 'Water Quanity', 'Agriculture' , 'Population' ];
		   
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_month[i+1] =[obj[i][0]+'-'+obj[i][1],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
			 
		  }
		  pie_cons_month[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_month[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_month[2]=['Population',Number(obj[1][3])];
		  	drawPieMonth(pie_cons_month);drawDevMonth(prodcons_month);
          }
          });
		   var prodcons_season=[];
		    var pie_cons_season=[];
		   $.ajax({
           url : '../php/get_prodcons_season_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_season[0]=['Season', 'Water Quanity', 'Agriculture' , 'Population'];
			
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_season[i+1] =[obj[i][1]+'('+obj[i][0]+')',Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		  
		  pie_cons_season[0]=['%', obj[1][0]+'-'+obj[1][1] ];
		  pie_cons_season[1]=['Agriculture',Number(obj[1][2])];
		  pie_cons_season[2]=['Population',Number(obj[1][3])];
		
		drawPieSeason(pie_cons_season);drawDevSeason(prodcons_season);
	
		
		
          }
          });
		   var related_farms=[];
		  $.ajax({
          url : '../php/get_related_farms.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{wr:selected_wr},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
	
		 for(var i = 0 ; i < obj.length;i++){
			
          	related_farms[i]=[obj[i][0],obj[i][1],obj[i][2]];
         }
		  $("#relatedFarms").html("");
		  $("#relatedFarms2").html("");
		   for(var j = 0 ; j < related_farms.length;j++){
			    $("#relatedFarms").append('<li>'+related_farms[j][0]+', '+related_farms[j][1]+', '+related_farms[j][2]+'.</li>');
	              $("#relatedFarms2").append('<li>'+related_farms[j][0]+', '+related_farms[j][1]+', '+related_farms[j][2]+'.</li>');
		  }
		  
          }
          });
		  	
	
	}

	);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		function drawPlants(data) {
			 //var data = google.visualization.arrayToDataTable(data2,false);
        // Some raw data (not necessarily accurate)
		
        var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       
 
    var options = {
		 
		width:400, 
		height: 400,
      title : 'Plant yeild depending on ECw',
      vAxis: { },
      hAxis: {title: 'Yeild%' ,viewWindow: { max:100,min:0}},
	  legend: 'none',
	  
	    bars: 'horizontal'
	   
    };
	 
    var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
    chart.draw(table, options);
  }
  function drawPlantsExp(data) {
			
		
        var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       
 
    var options = {
		 
		width:400, 
		height: 400,
      title : 'Plant yeild depending on the new ECw',
      vAxis: { },
      hAxis: {title: 'Yeild%' ,viewWindow: { max:100,min:0}},
	  legend: 'none',
	  
	    bars: 'horizontal'
	   
    };
	 
    var chart = new google.visualization.BarChart(document.getElementById('chart_div_exp'));
    chart.draw(table, options);
  }
  
  function drawHazardSar(sar_hazard) {
          
		  if(sar_hazard=="High"){$("#sarAlert").attr("src","../images/no.gif" );}
		   if( sar_hazard=="Moderate"){$("#sarAlert").attr("src","../images/mid.png" );}
		 if(sar_hazard=="Low"){$("#sarAlert").attr("src","../images/yes.png" );}
		 
		
		}
		 function drawHazardpH(ph_hazard) {
			 if(ph_hazard=="Low Range"||ph_hazard=="High Range"){$("#phAlert").attr("src","../images/no.gif" );}
		if(ph_hazard=="Normal Range"){$("#phAlert").attr("src","../images/yes.png" );}
		 }
		 function drawHazardEcw( ecw_hazard) {
			 
			  ecw_hazard = ecw_hazard.split("."); 
		 if(ecw_hazard[0]=="High hazard"){$("#ecwAlert").attr("src","../images/no.gif" );}
		   if( ecw_hazard[0]=="Medium hazard"|| ecw_hazard[0]=="Medium-high hazard"){$("#ecwAlert").attr("src","../images/mid.png" );}
		 if(ecw_hazard[0]=="Very low hazard"|| ecw_hazard[0]=="Low hazard"){$("#ecwAlert").attr("src","../images/yes.png" );}
		
		 }
		 function drawHazardB( b_hazard) {
			  if(b_hazard=="Tolerant"||b_hazard=="Very tolerant"){$("#bAlert").attr("src","../images/no.gif" );}
		   if( b_hazard=="Moderately sensitive"|| b_hazard=="Moderately tolerant"){$("#bAlert").attr("src","../images/mid.png" );}
		if(b_hazard=="Extremely sensitive"|| b_hazard=="Very sensitive"|| b_hazard=="Sensitive"){$("#bAlert").attr("src","../images/yes.png" );}
          
		 }
		 function drawHazardCl( cl_hazard) {
			 if(cl_hazard=="Can cause severe problems"){$("#clAlert").attr("src","../images/no.gif" );}
		   if( cl_hazard=="Moderately sensitive plants"){$("#clAlert").attr("src","../images/mid.png" );}
		 if(cl_hazard=="Safe for most plants"|| cl_hazard=="Sensitive plants" ){$("#clAlert").attr("src","../images/yes.png" );}
	   
		 }
		 function drawHazardRsc( rsc_hazard) {
			 if(rsc_hazard=="High" || rsc_hazard=="Very high"){$("#rscAlert").attr("src","../images/no.gif" );}
		   if( rsc_hazard=="Medium"){$("#rscAlert").attr("src","../images/mid.png" );}
		 if(rsc_hazard=="Low"){$("#rscAlert").attr("src","../images/yes.png" );}
	   
		 }
		  function drawHazardNo3( no3_hazard) {
			 if(no3_hazard=="High"){$("#no3Alert").attr("src","../images/no.gif" );}
		   if( no3_hazard=="Moderate"){$("#no3Alert").attr("src","../images/mid.png" );}
		 if(no3_hazard=="Low"){$("#no3Alert").attr("src","../images/yes.png" );}
	   
		 }
function drawDevYear(data) {
	
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: 'Total Consumption per m3 per Year',
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
		   vAxis: {title: '',  titleTextStyle: {color: '#333'}}
      
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_year'));
        chart.draw(table, options);
      }
	  function drawDevMonth(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: 'Total Consumption per m3 per Month',
          hAxis: {title: 'Month',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_month'));
        chart.draw(table, options);
      }
	   function drawDevSeason(data) {
		   
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: 'Total Consumption per m3 per Season',
          hAxis: {title: 'Season',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_season'));
        chart.draw(table, options);
      }
	  function drawPieMonth(data){
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: "Previous Month Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartMonth'));

        chart.draw(table, options);
  }
	  function drawPieYear(data){
		 
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: "Previous Year Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartYear'));

        chart.draw(table, options);
  }
   function drawPieSeason(data){
	   
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 400, height: 300,
          title: "Previous Season Percentage of Consumption per m3"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartSeason'));

        chart.draw(table, options);
		
  }
  

	function printDiv() 
{
  //Get the HTML of div
            var divElements = document.getElementById('content').innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            

            //Print Page
            window.print();

            
 /*  var divToPrint=document.getElementById('content');

  var newWin=window.open('','Print-Window');

  newWin.document.open();

  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');

  newWin.document.close();

  setTimeout(function(){newWin.close();},10);
 */
}

   
