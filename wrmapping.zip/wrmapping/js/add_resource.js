  
  var selected_city;
  var selected_region;
  var selected_type;
   var wr_name;
  var wr_x;
  var wr_y;
  $.ajax({
       url : '../php/city.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
         $("#sel1").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
	 $.ajax({
       url : '../php/resource_type.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][0];
          var name = obj[i][1];
         $("#sel3").append('<option value='+id+'>'+name+'</option>');
		  }
         
		 
       }
    }); 
	document.getElementById("sel1").addEventListener("change", function(){
		selected_city = $("#sel1" ).val();
		
		 $('#sel2')
    .find('option')
    .remove()
    .end()
    .append('<option value="0"></option>');
	 $.ajax({
       url : '../php/region_selected.php', 
	   data:{city_id: selected_city},
       type : 'POST',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		
          for(var i = 0 ; i < obj.length;i++){
          var id = obj[i][3];
          var name = obj[i][2];
   
 
         $("#sel2").append('<option value='+id+'>'+name+'</option>');
		  }
		 
        
       }
    });
	}
	);
	document.getElementById("sel2").addEventListener("change", function(){
		selected_region = $("#sel2" ).val();
		
		

	}
	);
	document.getElementById("sel3").addEventListener("change", function(){
		selected_type = $("#sel3" ).val();
		
		

	}
	);
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	$(document).ready(function(){
	
	 $("#add_btn").click(function(){	
		   var city=$("#sel1").val();
		   var region=$("#sel2").val();
		    var type=$("#sel3").val();
			var lat=$("#lat-input").val();
			var lng=$("#lng-input").val();
			var wr_name=$("#wr_name").val();
		  if($.trim(city).length>0 && $.trim(region).length>0 &&$.trim(type).length>0 && $.trim(lng).length>0&& $.trim(lat).length>0&& $.trim(wr_name).length>0){
			 
			
			  $.ajax({
		   type: "POST",
		   url: "../php/add_resource.php",
			data:{city:city,region:region,type:type,lat:lat,lng:lng, wr_name:wr_name},
			
		    success: function(data){    
		   if(data){
			  
			   $("#add_msg").html("<div class='alert alert-success alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong></div>");
		   }
		  
			else{
		    $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: complete fields!</strong></div>");
			  
			
			  }}
			});
			  
		  }
		  else{
			 if($.trim(type).length== 0 || $.trim(city).length== 0 || $.trim(region).length==0|| $.trim(lng).length==0|| $.trim(lat).length==0|| $.trim(wr_name).length==0){
				 
				 $("#add_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>failed: complete fields!</strong></div>");
				
			 }
				 
			
		  }
	});
});


	

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	