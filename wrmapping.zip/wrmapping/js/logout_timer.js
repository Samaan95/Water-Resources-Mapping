$(document).ready(function () {
  
  
var idleInterval = setInterval(timerIncrement, 1000);  
localStorage.getItem("timer_in");
    $(this).mousemove(function (e) {
       localStorage.setItem("timer",0);
	
    });
    $(this).keypress(function (e) {
      localStorage.setItem("timer",0);
	  	 
    });
});

function timerIncrement() {
    
	localStorage.setItem("timer",parseInt(localStorage.getItem("timer"))+1);
	
    if (parseInt(localStorage.getItem("timer"))==10 ) { 
	    
         window.location ='../php/logout.php';
       
		 	
    }
	
}
