if (window.location.protocol == "file:") {
    alert('This script only works when loaded from a web server,' +
        ' not from a file on your computer.');
  }
  function ftOnLoadClientApi() {
    gapi.client.setApiKey('AIzaSyCl-DZJeFdTqec7WZjmPfCTHs4xWW-6Ffw');
  }
var map;

  function loadApi() {
    gapi.client.load('fusiontables', 'v1', initialize);
  }

  function initialize() {
	  
    var mapDiv = document.getElementById('googft-mapCanvas');
    map = new google.maps.Map(mapDiv, {
      center: new google.maps.LatLng(31.85467274970951, 35.477914058184744),
      zoom: 10,
	  minZoom: 8, 
       mapTypeId: 'satellite'
    });
   

    onDataFetched();
  }

  function onDataFetched() {
	  $.ajax({
       url : '../php/city.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		  var city = [];
          for(var i = 0 ; i < obj.length;i++){
          var lat = obj[i][0];
          var lng = obj[i][1];
          var latLng = new google.maps.LatLng(lat, lng);
          city.push({ location: latLng,name:obj[i][2], city_id : obj[i][3], x: obj[i][0],y:obj[i][1]});
		  }
         
		  drawFusionmapCity(city);
		 
		  
       }
    });
	 $.ajax({
       url : '../php/region.php', 
       type : 'GET',
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		  var locations = [];
          for(var i = 0 ; i < obj.length;i++){
          var lat = obj[i][0];
          var lng = obj[i][1];
        
          var latLng = new google.maps.LatLng(lat, lng);
        
          locations.push({ location: latLng , name : obj[i][2] , city: obj[i][3], region_id: obj[i][4], x: obj[i][0],y:obj[i][1]});
		  }
		 
         drawFusionmapRegion(locations);
		  //drawFusionmapAlert(locations);
       }
    });
    $.ajax({
       url : '../php/wr.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	   
          var obj = jQuery.parseJSON(result);
		  var locations = [];
          for(var i = 0 ; i < obj.length;i++){
          var lat = obj[i][0];
          var lng = obj[i][1];
          var latLng = new google.maps.LatLng(lat, lng);
        
          locations.push({ location: latLng ,region_name:obj[i][3],city_name:obj[i][4],type:obj[i][5],wr_name:obj[i][6], x: obj[i][0],y:obj[i][1], wr_id: parseFloat(obj[i][2]) });
		  }
        
		  drawFusionmap(locations);
		  
       }
    });
		$.ajax({
       url : '../php/heatmap.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	  
          var obj = jQuery.parseJSON(result); 
		  var locations = [];
          for(var i = 0 ; i < obj.length;i++){
          var lat = obj[i][1];
          var lng = obj[i][2];
          var latLng = new google.maps.LatLng(lat, lng);
        
          locations.push({ location: latLng ,weight:Number(obj[i][0]) });
		 
		  }
		  
         drawHeatmap(locations);
		  
		  
       }
    });
	$.ajax({
       url : '../php/agri.php', // my php file
       type : 'GET', // type of the HTTP request
       success : function(result){ 
	     
          var obj = jQuery.parseJSON(result);
		  var locations = [];
          for(var i = 0 ; i < obj.length;i++){
          var lat = obj[i][2];
          var lng = obj[i][3];
        
          var latLng = new google.maps.LatLng(lat, lng);
        
          locations.push({ location: latLng , land_id: obj[i][0], land_name: obj[i][1], land_type: obj[i][4], land_area: obj[i][5], region_name: obj[i][6], city_name: obj[i][7], x: obj[i][2],y:obj[i][3]});
		  }
         
		  drawFusionmapAgri(locations);
       }
    });
   
	 
    
  }

  
  function drawHeatmap(locations) {
    var heatmap = new google.maps.visualization.HeatmapLayer({
       
       opacity: 0.6,
       radius: 30,
       data: locations,
	    gradient:  [
         'rgba(102,255,0,0)',   
		 'rgba(0, 255, 255, 1)',
          'rgba(0, 191, 255, 1)',
          'rgba(0, 127, 255, 1)',
          'rgba(0, 63, 255, 1)',
          'rgba(0, 0, 255, 1)',
          'rgba(0, 0, 223, 1)',
          'rgba(0, 0, 191, 1)',
          'rgba(0, 0, 159, 1)',
          'rgba(0, 0, 127, 1)',
          'rgba(63, 0, 91, 1)',
          'rgba(127, 0, 63, 1)',
          'rgba(191, 0, 31, 1)',
          'rgba(255, 0, 0, 1)'
       ]
	 
    });
	
        heatmap.setMap(map);
    
      

  }
 

 
   
  google.maps.event.addDomListener(window, 'load', loadApi);