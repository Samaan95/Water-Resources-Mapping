   function drawFusionmapAgri(locations) {
	  //draw markers
	  
var marker;
var markers = [];
$("#legend").append('<div class="col-sm-3"> <h5 style="font-size:17px;">Agricuture Farm<img src= "../images/farm.png"   width="40" height="40"/></h5></div>');

	 for (i = 0; i < locations.length; i++) {  
	  var infowindow = new google.maps.InfoWindow();
	   marker = new google.maps.Marker({
        position: locations[i]['location'],
		title:locations[i]['land_name'],
		icon: {url:'../images/farm.png', scaledSize: new google.maps.Size(40, 40)}
      });
	 
     
     
      google.maps.event.addListener(marker, 'click', (function(marker, i,locations) {
		  var p_name;
		  var p_needs=0;
		  var p_quantity = 0 ;
		  var p_date;
		  var p_season;
		  $.ajax({
           url : '../php/transplant_current.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{land_id:locations[i]['land_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
           p_name= obj[0][0];
		   p_needs=obj[0][1];
		  p_quantity = obj[0][2] ;
		  p_season = obj[0][3];
		    p_date = obj[0][4];
          }
          }); 
		  
		  var cons_land=[];
		   $.ajax({
           url : '../php/consumption_land_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{land_id:locations[i]['land_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
          var avg1=0;
			
             cons_land[0]=['Year', 'Consumption'];
		   
			for(var i = 0 ; i < obj.length;i++){
			 cons_land[i+1] =[obj[i][1]+'('+obj[i][3]+'-'+obj[i][2]+')',Number(obj[i][0])];  
            
			
		  }
		 
		 
          }
          });
		 
        return function() {
			var content= 
		    '<div class="panel panel-primary">'+
     ' <div class="panel-heading" style="background-color:#90b3a2">'+locations[i]['land_name']+'</div>'+
     ' <div class="panel-body" >'+
	  ' <div class="row">'+
  '<div class="col-sm-5">'+
    '<h5 style="color:black; padding-left:4%;"><strong><u>Agricuture Land Info</u></strong></h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Type: </strong>'+locations[i]['land_type']+'</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Area: </strong>'+locations[i]['land_area']+' m2</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Adrress: </strong>'+locations[i]['region_name']+', '+locations[i]['city_name']+'</h5>'+
		  '<h5 style="color:black; padding-left:4%; padding-bottom:1%"><strong>Coordinates: </strong>'+Number(locations[i]['x']).toFixed(4)+', '+Number(locations[i]['y']).toFixed(4)+'</h5>'+
  '</div>'+
 ' <div class="col-sm-5">'+
  '<h5 style="color:black; padding-left:4%;"><strong><u>Current Crop Info</u> </strong> </h5>'+
		 '<h5 style="color:black; padding-left:4%;"><strong>Crop: </strong> '+p_name+'</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Water need per unit: </strong>'+ p_needs+' m3</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Number of plants: </strong>'+ p_quantity +'</h5>'+
		   '<h5 style="color:black; padding-left:4%;"><strong>Transplanted on: </strong>'+ p_date+', '+p_season+'</h5>'+
 ' </div>'+
'</div>'+
	 
	 ' </div>'+
   ' </div>'+
		
		  ' <div id="chartLandConsumption" style="width: 500px; height: 300px"></div><hr>'
		  ;
		
		  
          infowindow.setContent(content);
          infowindow.open(map, marker);
		   drawLandConsumption(cons_land);
         
        }
      })(marker, i,locations));
	   markers.push(marker);
	
    }
	   google.maps.event.addListener(map, 'zoom_changed', function() {
var zoom = map.getZoom();
if(zoom >= 14){
		  
      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
}
else{
	      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(null);
       
    }
}
});
	
  }
  
  
  function drawLandConsumption(data) {
         var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       


        var options = {
          title: 'The total water consumption of crops per m3 per season',
		  colors: ['#90b3a2'],
          curveType: 'function'
         
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chartLandConsumption'));

        chart.draw(table, options);
      }
	    