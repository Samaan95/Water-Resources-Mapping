function drawFusionmapCity(locations) {
	  //draw markers
var marker;
var markers = [];
$("#legend").append('<div class="col-sm-3"> <h5 style="font-size:17px;">City<img src= "../images/flag.png"   width="40" height="40"/></h5></div>');
	 for (i = 0; i < locations.length; i++) {  
	  var infowindow = new google.maps.InfoWindow();
	   marker = new google.maps.Marker({
        position: locations[i]['location'],
         title: locations[i]['name'],
	  icon: {url:'../images/flag.png', scaledSize: new google.maps.Size(70, 70)}
      });
	  
     
     
      google.maps.event.addListener(marker, 'click', (function(marker, i,locations) {
		  var pop=[];
		  var totalAvg=0;
		   $.ajax({
           url : '../php/city_population.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{city_id:locations[i]['city_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);
         
             pop[0]=['Region', 'AVG Population'];
		   
			for(var i = 0 ; i < obj.length;i++){
			 pop[i+1] =[obj[i][0],Number(obj[i][1])];  
            totalAvg = totalAvg + Number(obj[i][1]);
		  }
		  
		 
          }
          });
		     var prodcons_year=[];
		   $.ajax({
           url : '../php/get_prodcons_year_city_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{city_id:locations[i]['city_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

            prodcons_year[0]=['Year', 'Water Quanity', 'Agriculture' , 'Population'];
		   
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_year[i+1] =[obj[i][0],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		 
          }
          });
		   var prodcons_month=[];
		   $.ajax({
           url : '../php/get_prodcons_month_city_last_5.php', // my php file
          type : 'POST', // type of the HTTP request
		  data:{city_id:locations[i]['city_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

          prodcons_month[0]=['Month', 'Water Quanity', 'Agriculture' , 'Population' ];
		   
			for(var i = 0 ; i < obj.length;i++){
			
			 prodcons_month[i+1] =[obj[i][0]+'-'+obj[i][1],Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
			 
		  }
		  
		 
          }
          });
		   var prodcons_season=[];
		   $.ajax({
           url : '../php/get_prodcons_season_city_last_5.php', // my php file
          type : 'POST', // type of the HTTP request.toFixed(1)
		  data:{city_id:locations[i]['city_id']},
          success : function(result){ 
          var obj = jQuery.parseJSON(result);

             prodcons_season[0]=['Season', 'Water Quanity', 'Agriculture' , 'Population'];
		   
			for(var i = 0 ; i < obj.length;i++){
			 
			 prodcons_season[i+1] =[obj[i][1]+'('+obj[i][0]+')',Number(obj[i][4]),Number(obj[i][2]),Number(obj[i][3])];  
		  }
		  
		  
		 
          }
          });
		  
		 
       return function() {
			 var content= 
		 '<div class="panel panel-primary">'+
     ' <div class="panel-heading" style="background-color:#53b7da" >City Info</div>'+
     ' <div class="panel-body">'+
	  '<h5 style="color:black; padding-left:4%;"><strong>City: </strong>'+locations[i]['name']+'</h5>'+
		  '<h5 style="color:black; padding-left:4%; padding-bottom:1%"><strong>Coordinates: </strong>'+Number(locations[i]['x']).toFixed(4)+', '+Number(locations[i]['y']).toFixed(4)+'</h5>'+
		  '<h5 style="color:black; padding-left:4%; padding-bottom:1%"><strong>Population AVG: </strong>'+totalAvg.toFixed(2)+'</h5>'+
	 ' </div>'+
   ' </div>'+
		   
		   '<h5 style="font-size: 15px;text-decoration: underline"><strong>Population</strong></h5>'+
             '<div id="piechartPop" ></div>'+
			   '<h5 style="font-size: 15px;text-decoration: underline"><strong>Water Consumption</strong></h5>'+
		   '<div id="chart_div_dev_month_city" ></div><hr>'+
		   '<div id="chart_div_dev_year_city" ></div>'+
		   '<div id="chart_div_dev_season_city" ></div>'
		 ;
          infowindow.setContent(content);
          infowindow.open(map, marker);
		   drawPop(pop);
		   
		   drawDevYearCity(prodcons_year);
		drawDevMonthCity(prodcons_month);
		drawDevSeasonCity(prodcons_season);
        } 
      })(marker, i,locations));
	   markers.push(marker);
	
    }
	for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
	   google.maps.event.addListener(map, 'zoom_changed', function() {
var zoom = map.getZoom();
if(zoom >= 8 && zoom <12){
		  
      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(map);
       
    }
}
else{
	      for (i = 0; i < locations.length; i++) {
		  markers[i].setMap(null);
       
    }
}
});
	
  } 

  function drawPop(data){
  var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
				width: 500, height: 300,
          title: "City's Populations AVG"
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechartPop'));

        chart.draw(table, options);
  }
    function drawDevYearCity(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Year',
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
		   vAxis: {title: '',  titleTextStyle: {color: '#333'}}
      
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_year_city'));
        chart.draw(table, options);
      }
	  function drawDevMonthCity(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Month',
          hAxis: {title: 'Month',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_month_city'));
        chart.draw(table, options);
      }
	   function drawDevSeasonCity(data) {
       var table = new google.visualization.DataTable();
             var dataa=data;
			 var numRows = dataa.length;
          var numCols = dataa[0].length;

          // in this case the first column is of type 'string'.
          table.addColumn('string', dataa[0][0]);

          // all other columns are of type 'number'.
          for (var i = 1; i < numCols; i++){
		  table.addColumn('number',dataa[0][i]); 
		  
		  }         

          // now add the rows.
          for (var i = numRows; i >= 1; i--){
			  
		  table.addRow(dataa[i]);  }       

        var options = {
			width: 500, height: 300,
          title: 'Total Consumption per m3 per Season',
          hAxis: {title: 'Season',  titleTextStyle: {color: '#333'}},
          vAxis: {title: '',  titleTextStyle: {color: '#333'}}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div_dev_season_city'));
        chart.draw(table, options);
      }