$(document).ready(function(){
	$('#username').on('input', function() {
	var input=$(this);
	var is_name=input.val();
	if(is_name){input.removeClass("invalid").addClass("valid");}
	else{input.removeClass("valid").addClass("invalid");}
});
$('#password').on('input', function() {
	var input=$(this);
	var is_name=input.val();
	if(is_name){input.removeClass("invalid").addClass("valid");}
	else{input.removeClass("valid").addClass("invalid");}
});
	 $("#login_btn").click(function(){	
		   var username=$("#username").val();
		   var password=$("#password").val();
		  if($.trim(username).length>0 && $.trim(password).length>0){
			  $.ajax({
		   type: "POST",
		   url: "../php/login.php",
			data:{username:username,password:password},
			cache:false,
		    success: function(data){    
		   if(data==true){
			
			 window.location.href = "../pages/user_page.php"; 
		   }
		  
			else{
		    
			  $("#login_msg").load(location.href + " #login_msg");
			
			}}
		  });
			  
		  }
		  else{
			  if($.trim(username).length==0 || $.trim(password).length==0){
				  $("#login_msg").html("<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>enter user name or password</strong></div>");
				  $('#username').addClass("invalid");
	              $('#password').addClass("invalid");
				  }
			
         
			 
		  }
	});
});

