<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select q.pH , p.hazard   from (select pH  from quality_parameters where wr_id = $wr_id order by date desc limit 1) q join ph_hazard p on q.pH> p.from and q.pH<= p.to ;";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['pH'], $enr['hazard']);
    array_push($data, $a);
}

echo json_encode($data);

?>