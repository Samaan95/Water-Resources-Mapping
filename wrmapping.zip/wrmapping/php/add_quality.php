<?php
session_start();

    include 'sql.php';
	
	$wr_id=$_POST['wr_id'];
	$date=$_POST['date'];
	$ec=$_POST['ec'];
	$na=$_POST['na'];
	$ca=$_POST['ca'];
	$mg=$_POST['mg'];
	$sar=$_POST['sar'];
	$hco=$_POST['hco'];
	$no=$_POST['no'];
	$co=$_POST['co'];
	$b=$_POST['b'];
	$cl=$_POST['cl'];
	$so=$_POST['so'];
	$ph=$_POST['ph'];
	
	
    $sql = "INSERT INTO quality_parameters (wr_id,ECw,Na,Ca,Mg,SAR,B,Cl,HCO3,NO3_N,SO4,`date`,pH,CO3)
VALUES ($wr_id,$ec,$na,$ca,$mg,$sar,$b,$cl,$hco,$no,$so,'$date',$ph,$co)";

if ($conn->query($sql) == TRUE) {
   echo true;
    
} else {
    echo false;
}

?>