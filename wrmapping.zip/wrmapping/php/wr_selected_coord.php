<?php
session_start();

    include 'sql.php';
	$region_id=$_POST['region_id'];
	$sql = "SELECT x_coord, y_coord FROM wr where wr_id=$region_id;";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['x_coord'], $enr['y_coord']);
    array_push($data, $a);
}

echo json_encode($data);

?>