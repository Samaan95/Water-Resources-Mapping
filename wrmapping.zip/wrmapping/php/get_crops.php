<?php
session_start();
include 'sql.php';
$region=$_POST['region'];
$sql = "SELECT  plant_id , plant_name from plant ; ";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['plant_id'], $enr['plant_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>