

<?php

/*session_start();
$connect = mysqli_connect("localhost", "root", "root", "wrmapping");
if(isset($_POST["username"]) && isset($_POST["password"]))
{
 $username = mysqli_real_escape_string($connect, $_POST["username"]);
 $password = mysqli_real_escape_string($connect, $_POST["password"]);
 $sql = "SELECT * FROM user WHERE user_name = '".$username."' AND user_password = '".$password."'";
 $result = mysqli_query($connect, $sql);
 $num_row = mysqli_num_rows($result);
 if($num_row > 0)
 {
  $data = mysqli_fetch_array($result);
  $_SESSION["user_name"] = $data["user_name"];
  $_SESSION["user_name"]=$data["user_name"];
		 $_SESSION["first_name"]=$data["first_name"];
		 $_SESSION["user_pic"]=$data["user_pic"];
		 $_SESSION['login_error']="";
  echo true;
 }
}*/
 session_start();


    include 'sql.php';
	$username=$_POST['username'];
	$password=$_POST['password'];
    $query="SELECT * FROM user u  join region r on r.region_id=u.region_id join city c on c.city_id = r.city_id join user_type t on t.type_id=u.user_type  where user_name= '$username' AND user_password='$password'";
	$result = $conn->query($query);
	$num_row = mysqli_num_rows($result);
	$row=$result->fetch_assoc();
	
	if($num_row>0){
	$_SESSION["user_name"]=$row["user_name"];
		 $_SESSION["first_name"]=$row["first_name"];
		  $_SESSION["last_name"]=$row["Last_name"];
		 
		 $_SESSION["user_pic"]=$row["user_pic"];
		  $_SESSION["user_gender"]=$row["user_gender"];
		   $_SESSION["user_age"]=$row["user_age"];
		   $_SESSION["user_phone"]=$row["user_phone"];
		 $_SESSION["user_type"]= $row["user_type"];
		  $_SESSION["region_name"]=$row["region_name"];
		 $_SESSION["city_name"]= $row["city_name"];
		  $_SESSION["email"]= $row["email"];
		   $_SESSION["type_name"]= $row["type_name"];
		 $_SESSION['login_error']="";
		 //$data = mysqli_fetch_array($result);
 
  echo true;

	}
	else if($row['user_active']==0 && $num_row>0){
	$_SESSION['login_error']="<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>this user is not active!</strong></div>" ;
	}
	else{
	  $_SESSION['login_error']="<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>user name or password is incorrect!</strong></div>" ;
	
         
		
	}
	 
	 
	
  
 
?>
