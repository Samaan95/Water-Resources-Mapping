<?php
session_start();

    include 'sql.php';
	$sql = "SELECT a.land_id, a.land_name, a.x_coord , a.y_coord, t.type_name, a.land_area, r.region_name , c.city_name FROM agri_land a join region r on a.region_id= r.region_id join land_type t on t.type_id=a.land_type join city c on r.city_id=c.city_id ;  ";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['land_id'],$enr['land_name'],$enr['x_coord'], $enr['y_coord'], $enr['type_name'], $enr['land_area'], $enr['region_name'], $enr['city_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>