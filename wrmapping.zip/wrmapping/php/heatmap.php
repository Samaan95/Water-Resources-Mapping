<?php
session_start();
include 'sql.php';
	
$sql = "
select x.ECw as ec , w.x_coord as x1, w.y_coord as y1 from ( select wr_id,ECw,  @num := if(@id = wr_id, @num + 1, 1) as row_number, @id := wr_id  from quality_parameters order by date desc) x join wr w on w.wr_id=x.wr_id where x.row_number <= 1;";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['ec'], $enr['x1'],$enr['y1'] );
    array_push($data, $a);
}

echo json_encode($data);

?>