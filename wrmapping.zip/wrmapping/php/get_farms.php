<?php
session_start();
include 'sql.php';
$region=$_POST['region'];
$sql = "SELECT  land_id , land_name from agri_land where region_id =$region ; ";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['land_id'], $enr['land_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>