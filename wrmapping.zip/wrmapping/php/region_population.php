<?php
session_start();

    include 'sql.php';
	$region_id= $_POST['region_id'];
	$sql = "SELECT  sum(p.pop_value)  as total_pop , p.age_group_from, p.age_group_to  FROM population p join region r on p.region_id = r.region_id  where r.region_id= $region_id group by  p.age_group_from ; ";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array($enr['age_group_from'] ,$enr['age_group_to'],$enr['total_pop']);
    array_push($data, $a);
}

echo json_encode($data);

?>