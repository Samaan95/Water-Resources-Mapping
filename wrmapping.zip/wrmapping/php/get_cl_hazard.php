<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select q.Cl, c.hazard as cl, c.crops as ccl from (select Cl   from quality_parameters where wr_id = $wr_id order by date desc limit 1) q join chloride_hazard c on q.Cl> c.from and q.Cl<= c.to ;";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['Cl'], $enr['cl'],$enr['ccl']);
    array_push($data, $a);
}

echo json_encode($data);

?>