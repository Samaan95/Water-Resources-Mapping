<?php
session_start();

    include 'sql.php';
	$sql = "SELECT x_coord,y_coord,city_name , city_id FROM city";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['x_coord'], $enr['y_coord'],$enr['city_name'],$enr['city_id']);
    array_push($data, $a);
}

echo json_encode($data);

?>