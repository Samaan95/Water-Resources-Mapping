<?php
session_start();

    include 'sql.php';
	
	$wr_id=$_POST['wr_id'];
	$date=$_POST['date'];
	$season=$_POST['season'];
	$quantity=$_POST['quantity'];
	
    $sql = "INSERT INTO wr_production (wr_id,production,`date`,`season`)
VALUES ($wr_id,$quantity,'$date', '$season')";

if ($conn->query($sql) == TRUE) {
   echo true;
    
} else {
    echo false;
}

?>