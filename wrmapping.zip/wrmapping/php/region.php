<?php
session_start();

    include 'sql.php';
	$sql = "SELECT r.x_coord, r.y_coord,r.region_name, c.city_name, r.region_id  FROM region r JOIN city c ON r.city_id=c.city_id;";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['x_coord'], $enr['y_coord'], $enr['region_name'], $enr['city_name'], $enr['region_id']);
    array_push($data, $a);
}

echo json_encode($data);

?>