<?php
session_start();

    include 'sql.php';
	$land_id=$_POST['land_id'];
	$sql = "SELECT p.plant_name, p.water_needs, t.quantity, t.season , t.date as date FROM  transplant t  join plant p on p.plant_id=t.plant_id where t.land_id=$land_id order by date desc limit 1  ;  ";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['plant_name'],$enr['water_needs'],$enr['quantity'], $enr['season'], $enr['date']);
    array_push($data, $a);
}

echo json_encode($data);

?>