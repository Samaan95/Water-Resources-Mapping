<?php
session_start();

    include 'sql.php';
	$region_id=$_POST['region'];
	$sql = "select * from population where region_id=$region_id group by region_id, age_group_from ; ";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array($enr['region_id'],$enr['age_group_from'],$enr['age_group_to']);
    array_push($data, $a);
}

echo json_encode($data);

?>