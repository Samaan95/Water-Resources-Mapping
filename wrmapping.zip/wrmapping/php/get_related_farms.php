<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select distinct l.land_name, r.region_name, t.city_name from (select * from wr_consumption_land where wr_id=$wr_id) c join wr w on w.wr_id =c.wr_id join region r on r.region_id=w.region_id  join agri_land l on l.region_id=r.region_id and l.land_id=c.land_id  join city t on t.city_id= r.city_id;";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['land_name'], $enr['region_name'],$enr['city_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>