<?php
session_start();

    include 'sql.php';
	$city_id= $_POST['city_id'];
	$sql = "SELECT  AVG(p.pop_value)  as total_pop , r.region_name FROM population p join region r on p.region_id = r.region_id join city c on r.city_id= c.city_id where c.city_id= $city_id group by  r.region_name ; ";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array($enr['region_name'] ,$enr['total_pop']);
    array_push($data, $a);
}

echo json_encode($data);

?>