<?php
session_start();
include 'sql.php';
	
$sql = "SELECT w.x_coord , w.y_coord, wr_id, region_name, city_name, type_name, wr_name FROM wr w JOIN region r ON w.region_id = r.region_id JOIN wr_type t ON t.type_id = w.wr_type JOIN city c ON r.city_id = c.city_id; ";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['x_coord'], $enr['y_coord'], $enr['wr_id'],$enr['region_name'],$enr['city_name'],$enr['type_name'],$enr['wr_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>