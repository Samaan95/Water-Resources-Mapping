<?php
session_start();

    include 'sql.php';
	$crop=$_POST['crop'];
	$farm=$_POST['farm'];
	$date=$_POST['date'];
	$season=$_POST['season'];
	$quantity=$_POST['quantity'];
	
    $sql = "INSERT INTO transplant (land_id, plant_id, quantity,`date`,`season`)
VALUES ($farm, $crop,$quantity,'$date', '$season')";

if ($conn->query($sql) == TRUE) {
   echo true;
    
} else {
    echo false;
}

?>