<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];

$sql2="select  s.hazard  from (select * from quality_parameters  where wr_id = $wr_id order by date desc limit 1) q join sar_hazard s on q.SAR> s.from and q.SAR <= s.to and s.ec_from < q.ECw and s.ec_to >= q.ECw ";
$result2=mysqli_query($conn, $sql2);
$data = array();
while($enr2 = mysqli_fetch_assoc($result2)){
    $a = array(  $enr2['hazard']);
    array_push($data, $a);
}

echo json_encode($data);

?>