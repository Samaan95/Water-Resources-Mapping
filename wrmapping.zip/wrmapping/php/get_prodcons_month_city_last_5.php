<?php
session_start();
include 'sql.php';
	$city_id=$_POST['city_id'];
$sql = "select year(p.date) as year , month(p.date) as month , cl.consumption as consl , cp.consumption as consp , p.production from 
(select sum(consumption) as consumption  , date from wr_consumption_land  join wr on wr.wr_id=wr_consumption_land.wr_id join region on region.region_id=wr.region_id where region.city_id= $city_id group by year(date),month(date)) cl 
right join 
(select sum(production)as production , date from wr_production join wr on wr.wr_id=wr_production.wr_id join region on region.region_id=wr.region_id where region.city_id= $city_id group by year(date),month(date) order by date desc limit 5) p on year(cl.date)= year(p.date) and month(cl.date)= month(p.date)
left join
(select sum(consumption) as consumption , date from wr_consumption_pop  join wr on wr.wr_id=wr_consumption_pop.wr_id join region on region.region_id=wr.region_id where region.city_id= $city_id group by year(date),month(date)) cp 
on year(cp.date)= year(p.date) and month(cp.date)= month(p.date)  order by p.date desc;
 ";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array(  $enr['year'],$enr['month'],$enr['consl'], $enr['consp'], $enr['production']);
    array_push($data, $a);
}

echo json_encode($data);

?>