<?php
session_start();
include 'sql.php';
	
$sql = "SELECT  type_id , type_name from wr_type ; ";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['type_id'], $enr['type_name']);
    array_push($data, $a);
}

echo json_encode($data);

?>