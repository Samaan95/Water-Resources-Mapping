<?php
session_start();

    include 'sql.php';
	$city_id=$_POST['city_id'];
	$sql = "SELECT x_coord, y_coord,region_name, region_id  FROM region where city_id=$city_id;";  
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['x_coord'], $enr['y_coord'], $enr['region_name'], $enr['region_id']);
    array_push($data, $a);
}

echo json_encode($data);

?>