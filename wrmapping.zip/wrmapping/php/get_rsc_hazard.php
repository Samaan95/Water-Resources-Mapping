<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select r.class,r.hazard,round((q.CO3/30 + q.HCO3/61)-(q.Mg/12.2 + q.Ca/20),2) as rsc from (select CO3, HCO3 ,Mg,Ca  from quality_parameters where wr_id = $wr_id order by date desc limit 1) q join rsc_hazard r on (q.CO3/30 + q.HCO3/61)-(q.Mg/12.2 + q.Ca/20)> r.from and (q.CO3/30 + q.HCO3/61)-(q.Mg/12.2 + q.Ca/20)<= r.to ;";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['class'], $enr['hazard'],$enr['rsc']);
    array_push($data, $a);
}

echo json_encode($data);

?>