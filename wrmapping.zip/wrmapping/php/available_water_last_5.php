<?php
session_start();
include 'sql.php';
	$wr=$_POST['wr'];
$sql1 = " select avg(c.consumption) as c from  (select  * from wr_consumption_pop  where wr_id =$wr   order by date desc limit 5) c group by c.wr_id; ";
$sql2 = " select avg(c.consumption) as c from  (select  * from wr_consumption_land  where wr_id =$wr   order by date desc limit 5) c group by c.wr_id; ";
$sql3 = " select  production  from wr_production  where wr_id =$wr   order by date desc limit 1; ";

$result1 = mysqli_query($conn, $sql1);
$result2 = mysqli_query($conn, $sql2);
$result3 = mysqli_query($conn, $sql3);

$enr1 = mysqli_fetch_assoc($result1);
$enr2 = mysqli_fetch_assoc($result2);
$enr3 = mysqli_fetch_assoc($result3);

$available= $enr3['production']-($enr1['c']+$enr2['c'])  ;

$data = array();

    $a = array($available);
    array_push($data, $a);


echo json_encode($data);

?>