<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select q.ECw , p.plant_name , e.Yeild ,q.date, ech.hazard as ech from (select * from quality_parameters  where wr_id = $wr_id order by date desc limit 1) q join ecw e on e.from < q.ECw and e.to >= q.ECw join plant p on p.plant_id = e.plant_id join ecw_hazard ech on ech.from < q.ECw and ech.to >= q.ECw  where e.yeild > 0 order by e.yeild ;";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array(  $enr['ECw'],$enr['plant_name'],$enr['Yeild'] ,$enr['date'],$enr['ech']);
    array_push($data, $a);
}

echo json_encode($data);

?>