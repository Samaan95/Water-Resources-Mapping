<?php
session_start();

    include 'sql.php';
	$city=$_POST['city'];
	$region=$_POST['region'];
	$type=$_POST['type'];
	$lat=$_POST['lat'];
	$lng=$_POST['lng'];
	$wr_name=$_POST['wr_name'];
    $sql = "INSERT INTO wr (x_coord, y_coord, region_id,wr_type,`wr_name`)
VALUES ($lat, $lng,$region,$type, '$wr_name')";

if ($conn->query($sql) == TRUE) {
   echo true;
    
} else {
    echo false;
}

?>