<?php
session_start();

    include 'sql.php';
	$name=$_POST['name'];
	$email=$_POST['email'];
	$comments=$_POST['comments'];
    $sql = "INSERT INTO contact_messages (cm_username, cm_email, cm_comment)
VALUES ('$name', '$email', '$comments')";

if ($conn->query($sql) === TRUE) {
	$_SESSION['contact_error']= "<div class='alert alert-success alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Success!</strong></div>";
   echo true;
    
} else {
	$_SESSION['contact_error']= "<div class='alert alert-danger alert-dismissable'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><strong>Failed!</strong></div>";
    echo false;
}

?>