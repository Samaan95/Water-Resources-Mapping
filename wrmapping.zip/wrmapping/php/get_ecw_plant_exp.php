<?php
session_start();
include 'sql.php';
	$ecw_tar=$_POST['ecw_targ'];
$sql = "select p.plant_name , e.Yeild  from  ecw e join plant p on p.plant_id = e.plant_id and e.from < $ecw_tar and e.to >= $ecw_tar    where e.yeild > 0 order by e.yeild";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array( $enr['plant_name'],$enr['Yeild'] );
    array_push($data, $a);
}

echo json_encode($data);

?>