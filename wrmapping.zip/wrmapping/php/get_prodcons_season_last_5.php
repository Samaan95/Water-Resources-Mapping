<?php
session_start();
include 'sql.php';
	$wr=$_POST['wr'];
$sql = "select year(p.date) as year , p.season, cl.consumption as consl , cp.consumption as consp , p.production from (select sum(consumption) as consumption , date from wr_consumption_land  where wr_id = $wr group by year(date),season) cl 
right join 
(select sum(production) as production , date, season from wr_production where wr_id= $wr group by year(date),season order by date desc  limit 5) p on year(cl.date)= year(p.date) and month(cl.date)= month(p.date)
left join
(select sum(consumption) as consumption , date from wr_consumption_pop  where wr_id = $wr group by year(date),season) cp on year(cp.date)= year(p.date) and month(cp.date)= month(p.date)  order by p.date desc,season;
 ";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array(  $enr['year'],$enr['season'],$enr['consl'], $enr['consp'], $enr['production']);
    array_push($data, $a);
}

echo json_encode($data);

?>