<?php
session_start();
include 'sql.php';
	$land_id=$_POST['land_id'];
$sql = "select cl.cons, p.plant_name , cl.year,cl.season from (select land_id,sum(consumption) as cons , year(date) as year, season from wr_consumption_land where land_id=$land_id group by year(date),season limit 5) cl
join transplant t on  t.land_id = cl.land_id and t.season = cl.season and year(t.date)=cl.year join plant p on p.plant_id=t.plant_id  order by date desc ; ";
$result = mysqli_query($conn, $sql);

$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array(  $enr['cons'],$enr['plant_name'],$enr['year'],$enr['season']);
    array_push($data, $a);
}

echo json_encode($data);

?>