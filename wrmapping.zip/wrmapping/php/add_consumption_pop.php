<?php
session_start();

    include 'sql.php';
	$wr_id=$_POST['wr_id'];
	$pop=$_POST['pop'];
	$date=$_POST['date'];
	$season=$_POST['season'];
	$consumption=$_POST['consumption'];
	
    $sql = "INSERT INTO wr_consumption_pop (wr_id,pop_id,consumption,`date`,`season`)
VALUES ($wr_id,$pop,$consumption,'$date', '$season')";

if ($conn->query($sql) == TRUE) {
   echo true;
    
} else {
    echo false;
}

?>