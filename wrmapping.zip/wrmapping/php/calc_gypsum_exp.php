<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];
$sql = "select q.ECw, s.ec_from  from (select * from quality_parameters  where wr_id = $wr_id order by date desc limit 1) q  join sar_hazard s on q.SAR> s.from and q.SAR <= s.to order by s.ec_from desc limit 1   ;";
$result = mysqli_query($conn, $sql);



$data = array();
while($enr = mysqli_fetch_assoc($result)){
    $a = array(  $enr['ECw'],$enr['ec_from']);
    array_push($data, $a);
}

echo json_encode($data);

?>