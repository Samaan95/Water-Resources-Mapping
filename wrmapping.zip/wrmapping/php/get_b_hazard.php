<?php
session_start();
include 'sql.php';
	$wr_id=$_POST['wr'];


$sql2 = "select q.B, b.hazard as b, b.crops as cb from (select  B   from quality_parameters where wr_id = $wr_id order by date desc limit 1 ) q  join boron_hazard b on q.B> b.from and q.B<= b.to;";
$result2 = mysqli_query($conn, $sql2);

$data = array();
while($enr2 = mysqli_fetch_assoc($result2)){
    $a = array( $enr2['B'],$enr2['b'] ,$enr2['cb']);
    array_push($data, $a);
}

echo json_encode($data);

?>